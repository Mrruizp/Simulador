--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: f_generar_correlativo(character varying); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION f_generar_correlativo(p_tabla character varying) RETURNS SETOF integer
    LANGUAGE plpgsql
    AS $$

	begin

		return query

		select 

			c.numero+1 

		from 

			correlativo c 

		where 

			c.tabla = p_tabla;

 end

 $$;


ALTER FUNCTION public.f_generar_correlativo(p_tabla character varying) OWNER TO ipvedupe;

--
-- Name: fn_calificarexamen(character varying, integer); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_calificarexamen(p_doc_id character varying, p_prueba_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$

declare

p_porcentaje_alumno float; -- Porcentaje obtenido del examen

p_descripcion character varying(50);

p_correlativo integer;

begin

				-- Eliminamos los registros de las respuestas del alumno.

				 -- delete from respuesta_pregunta_usuario

				 -- where doc_id = '45977448';

				select * into p_correlativo from f_generar_correlativo('promedio');

				select 

					((100 * sum(puntaje_correcto))/6) into p_porcentaje_alumno

				from 

					respuesta_pregunta_usuario r inner join pregunta p

				on

					r.pregunta_id = p.pregunta_id inner join prueba u

				on

					p.prueba_id = u.prueba_id

				where

					r.doc_id = p_doc_id and u.prueba_id = p_prueba_id;

				 if p_porcentaje_alumno >= 60 then

					p_descripcion = 'Aprobado';

				else

					p_descripcion = 'Desaprobado';

				end if;

			 		insert into promedio(promedio_id, porcentaje, descripcion)

					values(p_correlativo,p_porcentaje_alumno,p_descripcion);

					update 

						respuesta_pregunta_usuario 

					set 

						promedio_id = p_correlativo 

              		where 

						doc_id = p_doc_id;

					update 

						correlativo 

					set 

						numero = numero + 1 

              		where 

						tabla='promedio';

end

$$;


ALTER FUNCTION public.fn_calificarexamen(p_doc_id character varying, p_prueba_id integer) OWNER TO ipvedupe;

--
-- Name: fn_calificarexamennull(character varying, integer); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_calificarexamennull(p_doc_id character varying, p_prueba_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$

declare

p_correlativo integer;

respUsuaNull integer;

p_porcentaje_alumno float; -- Porcentaje obtenido del examen

p_descripcion character varying(50);

p_promedio_idd float;

begin

							-- verifica si este algún registro de promedio

							select 

								p.promedio_id into p_promedio_idd

							from 

								curso c inner join pregunta e 

							on

								c.curso_id = e.prueba_id inner join respuesta_pregunta_usuario r 

							on

								e.pregunta_id = r.pregunta_id inner join promedio p

							on 

								r.promedio_id = p.promedio_id

							where

								r.doc_id = p_doc_id

								and e.prueba_id = p_prueba_id or  r.respuesta_usuario is null;

								-- -----------------------------------------------

							select 

								count(r.respuesta_usuario) into respUsuaNull

							from 

								curso c inner join pregunta e 

							on

								c.curso_id = e.prueba_id left join respuesta_pregunta_usuario r 

							on

								e.pregunta_id = r.pregunta_id left join promedio p

							on 

								r.promedio_id = p.promedio_id

							where

								r.doc_id = p_doc_id

								and e.prueba_id = p_prueba_id or  r.respuesta_usuario is null;

						if p_promedio_idd is null then	

							if respUsuaNull = 0 then

								insert into promedio

															(

																promedio_id,

																porcentaje,

																descripcion,

																doc_id

															)

								values

									(

										(select * from f_generar_correlativo('promedio') as nc),

										0,

										'Desaprobado',

										p_doc_id

									);

							else

								select * into p_correlativo from f_generar_correlativo('promedio');

								select 

									((100 * sum(puntaje_correcto))/40) into p_porcentaje_alumno

								from 

									respuesta_pregunta_usuario r inner join pregunta p

								on

									r.pregunta_id = p.pregunta_id inner join prueba u

								on

									p.prueba_id = u.prueba_id

								where

									r.doc_id = p_doc_id and u.prueba_id = p_prueba_id;

								 if p_porcentaje_alumno >= 60 then

									p_descripcion = 'Aprobado';

								else

									p_descripcion = 'Desaprobado';

								end if;

									insert into promedio(promedio_id, porcentaje, descripcion, doc_id)

									values(p_correlativo,p_porcentaje_alumno,p_descripcion, p_doc_id);

									update 

										respuesta_pregunta_usuario 

									set 

										promedio_id = p_correlativo,

										estadocalificado = 'Si'

									where 

										doc_id = p_doc_id;

									update 

										correlativo 

									set 

										numero = numero + 1 

									where 

										tabla='promedio';

							end if;

						end if;

end

$$;


ALTER FUNCTION public.fn_calificarexamennull(p_doc_id character varying, p_prueba_id integer) OWNER TO ipvedupe;

--
-- Name: fn_editarusuario(integer, character varying, character varying, character varying, character varying, character varying, character varying, integer, character, character, character); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_editarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) RETURNS void
    LANGUAGE plpgsql
    AS $$

 begin

 							-- update usuario

								update 

									usuario

								set

									doc_id    = p_doc_id,

									nombres   = p_nombres,

									apellidos = p_apellidos,

									direccion = p_direccion,

									telefono  = p_telefono,

									email     = p_email,

									cargo_id  = p_cargo_id

								where 

									doc_id = p_doc_id;

								-- update credenciales_acceso

								update 

									credenciales_acceso

								set

									clave  = (select md5(p_clave)),

									tipo   = p_tipo,

									estado = p_estado,

									doc_id = p_doc_id

								where 

									doc_id = p_doc_id;

 end

 $$;


ALTER FUNCTION public.fn_editarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) OWNER TO ipvedupe;

--
-- Name: fn_editarusuario(integer, character varying, character varying, character varying, character varying, character varying, character, character, character varying, integer, character, character, character); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_editarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) RETURNS void
    LANGUAGE plpgsql
    AS $$

 begin

 							-- update usuario

								update 

									usuario

								set

									doc_id    = p_doc_id,

									nombres   = p_nombres,

									apellidos = p_apellidos,

									direccion = p_direccion,

									telefono  = p_telefono,

									sexo      = p_sexo,

									edad      = p_edad,

									email     = p_email,

									cargo_id  = p_cargo_id

								where 

									doc_id = p_doc_id;

								-- update credenciales_acceso

								update 

									credenciales_acceso

								set

									clave  = (select md5(p_clave)),

									tipo   = p_tipo,

									estado = p_estado,

									doc_id = p_doc_id

								where 

									doc_id = p_doc_id;

 end

 $$;


ALTER FUNCTION public.fn_editarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) OWNER TO ipvedupe;

--
-- Name: fn_eliminarcursopruebapregunta(integer); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_eliminarcursopruebapregunta(p_curso_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$

declare

	p_prueba_id integer;

	p_pregunta_id integer;

begin

			-- Obtenemos el código de la prueba que pertenece a un curso y así para poder eliminarlo

				select 

					p.prueba_id into p_prueba_id

				from 

					curso c inner join prueba p

				on 

					c.curso_id = p.curso_id

				where 

					c.curso_id = p_curso_id;

			-- Obtenemos el código de la pregunta que pertenece a una prueba y así poder eliminarlo

				select 

					r.pregunta_id into p_pregunta_id

				from 

					prueba p inner join pregunta r

				on 

					r.prueba_id = p_prueba_id

				where 

					r.prueba_id = p_prueba_id;

			-- Eliminamos:

			-- pregunta

				delete from pregunta

				where pregunta_id = p_pregunta_id;

			-- prueba

				delete from prueba

				where prueba_id = p_prueba_id;

			-- curso

				delete from curso

				where curso_id = p_curso_id;

end

$$;


ALTER FUNCTION public.fn_eliminarcursopruebapregunta(p_curso_id integer) OWNER TO ipvedupe;

--
-- Name: fn_eliminarrespuestapromedio(character varying, integer); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_eliminarrespuestapromedio(p_doc_id character varying, p_prueba_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$

declare

	contador int := 0;

	i int := 0;

	j integer := 40;

	cont character varying(3);

	p_promedio_iddd integer;

begin

							delete from respuesta_pregunta_usuario

							where doc_id = p_doc_id and estadoCalificado is null;

							select 

								distinct p.promedio_id into p_promedio_iddd

							from 

								promedio p left join respuesta_pregunta_usuario r

							on

								p.promedio_id = r.promedio_id left join pregunta e

							on 

								r.pregunta_id = e.pregunta_id

							where p.doc_id = p_doc_id and e.prueba_id = p_prueba_id or  r.respuesta_usuario is null;

							delete from respuesta_pregunta_usuario

							where promedio_id = p_promedio_iddd;

							delete from promedio

							where promedio_id = p_promedio_iddd;

							LOOP

								EXIT when contador >= j;

								contador = contador +1;

									insert into respuesta_pregunta_usuario(respuesta_pregunta_usuario_id, respuesta_usuario, doc_id, numpregunta)

									values

									(

										(select * from f_generar_correlativo('respuesta_pregunta_usuario') as nc),

										'falta',

										p_doc_id,

										contador

									);

									update 

										correlativo 

									set 

										numero = numero + 1 

									where 

										tabla='respuesta_pregunta_usuario';

							end loop;

							-- select * from respuesta_pregunta_usuario

end

$$;


ALTER FUNCTION public.fn_eliminarrespuestapromedio(p_doc_id character varying, p_prueba_id integer) OWNER TO ipvedupe;

--
-- Name: fn_eliminarusuario(character varying); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_eliminarusuario(p_doc_id character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$

 BEGIN

				-- Eliminar credenciales_acceso

						delete from credenciales_acceso

						where doc_id = p_doc_id;

				-- Eliminar usuario

 						delete from usuario

						where doc_id = p_doc_id;

 end

 $$;


ALTER FUNCTION public.fn_eliminarusuario(p_doc_id character varying) OWNER TO ipvedupe;

--
-- Name: fn_registrareditarprueba(integer, character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_registrareditarprueba(p_prueba_id integer, p_cant_preguntas character varying, p_tiempo_prueba character varying, p_puntaje_aprobacion integer, p_curso_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$

begin

						IF 

							(select count(prueba_id) from prueba where curso_id = p_curso_id) = 1 then

							update prueba

							set 

								cant_preguntas 	     = p_cant_preguntas,

								tiempo_prueba		 = p_tiempo_prueba,

								puntaje_aprobacion   = p_puntaje_aprobacion

							where

								curso_id = p_curso_id;

						ELSE

							insert into prueba(

												prueba_id,

												cant_preguntas, 

												tiempo_prueba,

												puntaje_aprobacion,

												curso_id

											)

							values(

									p_curso_id,

									p_cant_preguntas, 

									p_tiempo_prueba,

									p_puntaje_aprobacion,

									p_curso_id

								  );

						END if;

end

$$;


ALTER FUNCTION public.fn_registrareditarprueba(p_prueba_id integer, p_cant_preguntas character varying, p_tiempo_prueba character varying, p_puntaje_aprobacion integer, p_curso_id integer) OWNER TO ipvedupe;

--
-- Name: fn_registrarrespuestausuario(character, integer, character varying); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_registrarrespuestausuario(p_respuesta_usuario character, p_pregunta_id integer, p_doc_id character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$

declare

	p_valor integer;

	p_respuesta_correcta char(1); -- respuesta de la pregunta

	-- p_respuesta_usuario char(1); -- respuesta del usuario

	p_puntaje_correcto float;    -- si respuesta pregunta == respuesta usuario ----> 1

	p_estado character varying(100); -- correcto - incorrecto

	p_correlativo integer;

	p_prueba_id integer;

	p_descripcionn character varying(200);

begin

				select                         

					p.descripcion into p_descripcionn

				from 

					curso c inner join pregunta e 

				on

					c.curso_id = e.prueba_id inner join respuesta_pregunta_usuario r 

				on

					e.pregunta_id = r.pregunta_id inner join promedio p

				on 

					r.promedio_id = p.promedio_id

				where

					r.doc_id = p_doc_id

					and e.prueba_id = p_prueba_id or  r.respuesta_usuario is null;

				select prueba_id into p_prueba_id from pregunta where pregunta_id = p_pregunta_id;

				select count(*) into p_valor from respuesta_pregunta_usuario where pregunta_id = p_pregunta_id;

				select respuesta into p_respuesta_correcta from pregunta where pregunta_id = p_pregunta_id;

				if p_descripcionn is null then

						if p_respuesta_usuario = p_respuesta_correcta  then

							p_puntaje_correcto = 1;

							p_estado = 'Correcto';

						else

							p_puntaje_correcto = 0;

							p_estado = 'Incorrecto';

						end if;	

						-- Verificar si es para registrar o actualizar registro

						if p_valor = 1 then

							update respuesta_pregunta_usuario

							set 

								respuesta_usuario = p_respuesta_usuario,

								puntaje_correcto = p_puntaje_correcto,

								estado = p_estado

							where

								pregunta_id = p_pregunta_id

							and

								doc_id = p_doc_id;

						else

							insert into respuesta_pregunta_usuario

																	(

																		respuesta_pregunta_usuario_id,

																		respuesta_usuario,

																		puntaje_correcto,

																		estado,

																		pregunta_id,

																		doc_id

																	)

							values

								(

									(select * from f_generar_correlativo('respuesta_pregunta_usuario') as nc),

									p_respuesta_usuario,

									p_puntaje_correcto,

									p_estado,

									p_pregunta_id,

									p_doc_id

								);

							update 

								correlativo 

							set 

								numero = numero + 1 

							where 

								tabla='respuesta_pregunta_usuario';

						end if;

				end if;

						-- Eliminamos los registros de las respuestas del alumno.

						 -- delete from promedio

						 -- where doc_id = '45977448';

end

$$;


ALTER FUNCTION public.fn_registrarrespuestausuario(p_respuesta_usuario character, p_pregunta_id integer, p_doc_id character varying) OWNER TO ipvedupe;

--
-- Name: fn_registrarrespuestausuario(character varying, integer, character varying, character varying); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_registrarrespuestausuario(p_respuesta_usuario character varying, p_pregunta_id integer, p_numpregunta character varying, p_doc_id character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$

declare

	p_valor integer;

	p_respuesta_correcta character varying(500); -- respuesta de la pregunta

	-- p_respuesta_usuario char(1); -- respuesta del usuario

	p_puntaje_correcto float;    -- si respuesta pregunta == respuesta usuario ----> 1

	p_estado character varying(100); -- correcto - incorrecto

	p_correlativo integer;

	p_prueba_id integer;

	p_descripcionn character varying(200);

	-- p_numPregunta character varying(3);

begin

				select                         

					p.descripcion into p_descripcionn

				from 

					curso c inner join pregunta e 

				on

					c.curso_id = e.prueba_id inner join respuesta_pregunta_usuario r 

				on

					e.pregunta_id = r.pregunta_id inner join promedio p

				on 

					r.promedio_id = p.promedio_id

				where

					r.doc_id = p_doc_id

					and e.prueba_id = p_prueba_id or  r.respuesta_usuario is null;

				select prueba_id into p_prueba_id from pregunta where pregunta_id = p_pregunta_id;

				select count(*) into p_valor from respuesta_pregunta_usuario where pregunta_id = p_pregunta_id and doc_id = p_doc_id;

				select respuesta into p_respuesta_correcta from pregunta where pregunta_id = p_pregunta_id;

				if p_descripcionn is null then

						if p_respuesta_usuario = p_respuesta_correcta  then

							p_puntaje_correcto = 1;

							p_estado = 'Correcto';

						else

							p_puntaje_correcto = 0;

							p_estado = 'Incorrecto';

						end if;	

						-- Verificar si es para registrar o actualizar registro

						if p_valor = 1 then

							update respuesta_pregunta_usuario

							set 

								respuesta_usuario = p_respuesta_usuario,

								puntaje_correcto = p_puntaje_correcto,

								estado = p_estado

							where

								pregunta_id = p_pregunta_id

							and

								doc_id = p_doc_id;

						else

							/*insert into respuesta_pregunta_usuario

																	(

																		respuesta_pregunta_usuario_id,

																		doc_id,

																		numpregunta

																	)

							values

								(

									(select * from f_generar_correlativo('respuesta_pregunta_usuario') as nc),

									p_respuesta_usuario,

									p_puntaje_correcto,

									p_estado,

									p_pregunta_id,

									p_doc_id,

									p_numPregunta

								);*/

							update 

								respuesta_pregunta_usuario

							set 

								respuesta_usuario = p_respuesta_usuario,

								puntaje_correcto = p_puntaje_correcto,

								estado = p_estado,

								pregunta_id = p_pregunta_id

							where

								doc_id = p_doc_id and

								numPregunta = p_numPregunta;

							update 

								correlativo 

							set 

								numero = numero + 1 

							where 

								tabla='respuesta_pregunta_usuario';

						end if;

				end if;

						-- Eliminamos los registros de las respuestas del alumno.

						 -- delete from promedio

						 -- where doc_id = '45977448';

end

$$;


ALTER FUNCTION public.fn_registrarrespuestausuario(p_respuesta_usuario character varying, p_pregunta_id integer, p_numpregunta character varying, p_doc_id character varying) OWNER TO ipvedupe;

--
-- Name: fn_registrarusuario(integer, character varying, character varying, character varying, character varying, character varying, character varying, integer, character, character, character); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_registrarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) RETURNS void
    LANGUAGE plpgsql
    AS $$

 begin

							insert into usuario

									(

										doc_id,nombres,apellidos,direccion,

										telefono, email,cargo_id

									)

							values

								(

									p_doc_id,p_nombres,p_apellidos,p_direccion,

									p_telefono,p_email,p_cargo_id

								);

-- select * from candidato                    

								insert into credenciales_acceso(codigo_usuario, clave,tipo,estado,fecha_registro,doc_id) 

								values (p_codigo_usuario,(select md5(p_clave)),p_tipo,p_estado,(select now()),p_doc_id);

 end

 $$;


ALTER FUNCTION public.fn_registrarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) OWNER TO ipvedupe;

--
-- Name: fn_registrarusuario(integer, character varying, character varying, character varying, character varying, character varying, character, character, character varying, integer, character, character, character); Type: FUNCTION; Schema: public; Owner: ipvedupe
--

CREATE FUNCTION fn_registrarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) RETURNS void
    LANGUAGE plpgsql
    AS $$

 begin

							insert into usuario

									(

										doc_id,nombres,apellidos,direccion,

										telefono,sexo,edad, email,cargo_id

									)

							values

								(

									p_doc_id,p_nombres,p_apellidos,p_direccion,

									p_telefono,p_sexo,p_edad,p_email,p_cargo_id

								);

								insert into credenciales_acceso(codigo_usuario, clave,tipo,estado,fecha_registro,doc_id) 

								values (p_codigo_usuario,(select md5(p_clave)),p_tipo,p_estado,(select now()),p_doc_id);

 end

 $$;


ALTER FUNCTION public.fn_registrarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) OWNER TO ipvedupe;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: anuncio; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE anuncio (
    anuncio_id integer NOT NULL,
    titulo_evento character varying(200) NOT NULL,
    descripcion_evento character varying(500) NOT NULL,
    tipo_anuncio character varying(50) NOT NULL
);


ALTER TABLE public.anuncio OWNER TO ipvedupe;

--
-- Name: cargo; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE cargo (
    cargo_id integer NOT NULL,
    descripcion character varying(50) NOT NULL
);


ALTER TABLE public.cargo OWNER TO ipvedupe;

--
-- Name: cargo_cargo_id_seq; Type: SEQUENCE; Schema: public; Owner: ipvedupe
--

CREATE SEQUENCE cargo_cargo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cargo_cargo_id_seq OWNER TO ipvedupe;

--
-- Name: cargo_cargo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ipvedupe
--

ALTER SEQUENCE cargo_cargo_id_seq OWNED BY cargo.cargo_id;


--
-- Name: correlativo; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE correlativo (
    tabla character varying(100) NOT NULL,
    numero integer NOT NULL
);


ALTER TABLE public.correlativo OWNER TO ipvedupe;

--
-- Name: credenciales_acceso; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE credenciales_acceso (
    codigo_usuario integer NOT NULL,
    clave character(32) NOT NULL,
    tipo character(1) NOT NULL,
    estado character(1),
    fecha_registro character varying(50),
    doc_id character varying(20)
);


ALTER TABLE public.credenciales_acceso OWNER TO ipvedupe;

--
-- Name: curso; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE curso (
    curso_id integer NOT NULL,
    nombre_curso character varying(200) NOT NULL
);


ALTER TABLE public.curso OWNER TO ipvedupe;

--
-- Name: detalle_usuario_curso_evento; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE detalle_usuario_curso_evento (
    detalle_usuario_curso_evento_id integer NOT NULL,
    fecha character varying(50) NOT NULL,
    doc_id character varying(20),
    anuncio_id integer,
    curso_id integer
);


ALTER TABLE public.detalle_usuario_curso_evento OWNER TO ipvedupe;

--
-- Name: menu; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE menu (
    codigo_menu integer NOT NULL,
    nombre character varying(50) NOT NULL
);


ALTER TABLE public.menu OWNER TO ipvedupe;

--
-- Name: menu_item; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE menu_item (
    codigo_menu integer NOT NULL,
    codigo_menu_item integer NOT NULL,
    nombre character varying(50) NOT NULL,
    archivo character varying(100) NOT NULL
);


ALTER TABLE public.menu_item OWNER TO ipvedupe;

--
-- Name: menu_item_accesos; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE menu_item_accesos (
    codigo_menu integer NOT NULL,
    codigo_menu_item integer NOT NULL,
    cargo_id integer NOT NULL,
    acceso character(1) NOT NULL
);


ALTER TABLE public.menu_item_accesos OWNER TO ipvedupe;

--
-- Name: pregunta; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE pregunta (
    pregunta_id integer NOT NULL,
    nombre_pregunta character varying(12000) NOT NULL,
    prueba_id integer,
    alternativa1 character varying(500),
    alternativa2 character varying(500),
    alternativa3 character varying(500),
    alternativa4 character varying(500),
    respuesta character varying(500)
);


ALTER TABLE public.pregunta OWNER TO ipvedupe;

--
-- Name: promedio; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE promedio (
    promedio_id integer NOT NULL,
    porcentaje double precision NOT NULL,
    descripcion character varying(200) NOT NULL,
    doc_id character varying(20)
);


ALTER TABLE public.promedio OWNER TO ipvedupe;

--
-- Name: prueba; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE prueba (
    prueba_id integer NOT NULL,
    cant_preguntas character varying(4) NOT NULL,
    tiempo_prueba character varying(50) NOT NULL,
    puntaje_aprobacion integer NOT NULL,
    curso_id integer
);


ALTER TABLE public.prueba OWNER TO ipvedupe;

--
-- Name: respuesta_pregunta_usuario; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE respuesta_pregunta_usuario (
    respuesta_pregunta_usuario_id integer NOT NULL,
    respuesta_usuario character varying(500) NOT NULL,
    puntaje_correcto double precision,
    estado character varying(100),
    pregunta_id integer,
    doc_id character varying(20) NOT NULL,
    promedio_id integer,
    estadocalificado character(2),
    numpregunta character varying(3) NOT NULL
);


ALTER TABLE public.respuesta_pregunta_usuario OWNER TO ipvedupe;

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: ipvedupe; Tablespace: 
--

CREATE TABLE usuario (
    doc_id character varying(20) NOT NULL,
    nombres character varying(50) NOT NULL,
    apellidos character varying(50) NOT NULL,
    direccion character varying(200) NOT NULL,
    telefono character varying(25) NOT NULL,
    email character varying(150) NOT NULL,
    cargo_id integer
);


ALTER TABLE public.usuario OWNER TO ipvedupe;

--
-- Name: cargo_id; Type: DEFAULT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY cargo ALTER COLUMN cargo_id SET DEFAULT nextval('cargo_cargo_id_seq'::regclass);


--
-- Data for Name: anuncio; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO anuncio VALUES (1, 'Project Manager', '--------------------------------------', 'Informativo');


--
-- Data for Name: cargo; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO cargo VALUES (1, 'Director general');
INSERT INTO cargo VALUES (2, 'Gerente General');
INSERT INTO cargo VALUES (3, 'Coordinadora académica');
INSERT INTO cargo VALUES (4, 'Analista Programador');
INSERT INTO cargo VALUES (5, 'Docente');
INSERT INTO cargo VALUES (6, 'Estudiante');


--
-- Name: cargo_cargo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ipvedupe
--

SELECT pg_catalog.setval('cargo_cargo_id_seq', 1, false);


--
-- Data for Name: correlativo; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO correlativo VALUES ('cargo', 0);
INSERT INTO correlativo VALUES ('menu', 0);
INSERT INTO correlativo VALUES ('menu_item', 0);
INSERT INTO correlativo VALUES ('menu_item_accesos', 0);
INSERT INTO correlativo VALUES ('detalle_usuario_curso_evento', 0);
INSERT INTO correlativo VALUES ('promedio', 38);
INSERT INTO correlativo VALUES ('pregunta', 79);
INSERT INTO correlativo VALUES ('anuncio', 1);
INSERT INTO correlativo VALUES ('credenciales_acceso', 12);
INSERT INTO correlativo VALUES ('usuario', 1);
INSERT INTO correlativo VALUES ('prueba', 5);
INSERT INTO correlativo VALUES ('curso', 30);
INSERT INTO correlativo VALUES ('respuesta_pregunta_usuario', 7546);


--
-- Data for Name: credenciales_acceso; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO credenciales_acceso VALUES (2, '8d5e957f297893487bd98fa830fa6413', 'A', 'A', '2020-04-13 11:50:40.94904-04', '47412369');
INSERT INTO credenciales_acceso VALUES (3, '202cb962ac59075b964b07152d234b70', 'E', 'A', '2020-04-13 17:23:28.092963-04', '4561233');
INSERT INTO credenciales_acceso VALUES (6, '8e49594c7a8d360c63760e4ba9c46f86', 'E', 'A', '2020-04-22 12:19:21.44796-04', '70184250');
INSERT INTO credenciales_acceso VALUES (8, '97dceafd2ed588126aae2fd622c815c0', 'D', 'A', '2020-04-22 12:29:53.52507-04', '44643430');
INSERT INTO credenciales_acceso VALUES (9, '5d9115beebc632582b11395f94e10505', 'A', 'A', '2020-04-22 12:48:32.140924-04', '45977448');
INSERT INTO credenciales_acceso VALUES (10, '6bc20e9700dda71ae56080caeb7a43c2', 'E', 'A', '2020-04-23 02:23:07.136497-04', '07853952');
INSERT INTO credenciales_acceso VALUES (11, 'a614170c8a6ce09c2fc25e31229f7498', 'A', 'A', '2020-04-23 02:24:21.782602-04', '70464700');
INSERT INTO credenciales_acceso VALUES (1, '9cb3fd912b09fa42c9ab91a047f3b584', 'A', 'A', '2020-04-10 01:27:09.622412-04', '78998521');
INSERT INTO credenciales_acceso VALUES (7, '7d9487732dc33cfbf99458d6e4558a1d', 'E', 'A', '2020-04-22 12:28:17.293541-04', '71407684');
INSERT INTO credenciales_acceso VALUES (5, '0ef00bdd9cba968ea08a7d182a3b6cef', 'E', 'A', '2020-04-22 11:16:14.661135-04', '76407327');
INSERT INTO credenciales_acceso VALUES (12, '202cb962ac59075b964b07152d234b70', 'D', 'A', '2020-04-23 10:36:30.563305-04', '88888888');


--
-- Data for Name: curso; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO curso VALUES (1, 'Agile Coach');
INSERT INTO curso VALUES (2, 'Innovation Management');
INSERT INTO curso VALUES (3, 'Kanban');
INSERT INTO curso VALUES (4, 'Scrum Master');
INSERT INTO curso VALUES (5, 'Scrum Foundation');
INSERT INTO curso VALUES (6, 'Scrum Developer');
INSERT INTO curso VALUES (7, 'Scrum Advanced');
INSERT INTO curso VALUES (8, 'Scrum Product Owner');
INSERT INTO curso VALUES (9, 'Iso 27001 Auditor');
INSERT INTO curso VALUES (10, 'Iso 27001 Lead Auditor');
INSERT INTO curso VALUES (11, 'Iso 27001 Foundation');
INSERT INTO curso VALUES (12, 'Iso 22301 Auditor');
INSERT INTO curso VALUES (13, 'Iso 22301 Lead Auditor');
INSERT INTO curso VALUES (14, 'Iso 22301 Foundation');
INSERT INTO curso VALUES (15, 'Iso 20000 Auditor');
INSERT INTO curso VALUES (16, 'Iso 20000 Lead Auditor');
INSERT INTO curso VALUES (17, 'Iso 20000 Foundation');
INSERT INTO curso VALUES (18, 'Cybersecurity');
INSERT INTO curso VALUES (19, 'Six Sigma');
INSERT INTO curso VALUES (20, 'DevOps Essentials');
INSERT INTO curso VALUES (21, 'DevOps Culture');
INSERT INTO curso VALUES (22, 'Marketing Digital');
INSERT INTO curso VALUES (23, 'Big Data');
INSERT INTO curso VALUES (24, 'Design Thinking');
INSERT INTO curso VALUES (25, 'Service Desk');
INSERT INTO curso VALUES (26, 'Agile Business Owner');


--
-- Data for Name: detalle_usuario_curso_evento; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--



--
-- Data for Name: menu; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO menu VALUES (1, 'Inicio');
INSERT INTO menu VALUES (2, 'Anuncio');
INSERT INTO menu VALUES (3, 'Usuario');
INSERT INTO menu VALUES (4, 'Perfil');
INSERT INTO menu VALUES (5, 'Campus Virtual');
INSERT INTO menu VALUES (6, 'Simulador');


--
-- Data for Name: menu_item; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO menu_item VALUES (1, 1, 'Inicio', 'menu.principal.view.php');
INSERT INTO menu_item VALUES (2, 4, 'Gestionar Anuncios', 'gestionarAnuncios.view.php');
INSERT INTO menu_item VALUES (3, 5, 'Gestionar Usuario', 'gestionarUsuario.view.php');
INSERT INTO menu_item VALUES (4, 7, 'Datos Personales', 'datosPersonales.view.php');
INSERT INTO menu_item VALUES (5, 9, 'Gestionar Curso', 'gestionarCurso.view.php');
INSERT INTO menu_item VALUES (6, 12, 'Simulador', 'pruebaSimulador.view.php');
INSERT INTO menu_item VALUES (6, 13, 'Gestionar Simulador', 'gestionarCurso.view.php');


--
-- Data for Name: menu_item_accesos; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO menu_item_accesos VALUES (3, 5, 1, '1');
INSERT INTO menu_item_accesos VALUES (4, 7, 1, '1');
INSERT INTO menu_item_accesos VALUES (6, 12, 1, '1');
INSERT INTO menu_item_accesos VALUES (3, 5, 2, '1');
INSERT INTO menu_item_accesos VALUES (4, 7, 2, '1');
INSERT INTO menu_item_accesos VALUES (6, 12, 2, '1');
INSERT INTO menu_item_accesos VALUES (3, 5, 3, '1');
INSERT INTO menu_item_accesos VALUES (4, 7, 3, '1');
INSERT INTO menu_item_accesos VALUES (6, 12, 3, '1');
INSERT INTO menu_item_accesos VALUES (3, 5, 4, '1');
INSERT INTO menu_item_accesos VALUES (4, 7, 4, '1');
INSERT INTO menu_item_accesos VALUES (6, 12, 4, '1');
INSERT INTO menu_item_accesos VALUES (3, 5, 5, '2');
INSERT INTO menu_item_accesos VALUES (4, 7, 5, '1');
INSERT INTO menu_item_accesos VALUES (6, 12, 5, '1');
INSERT INTO menu_item_accesos VALUES (3, 5, 6, '2');
INSERT INTO menu_item_accesos VALUES (4, 7, 6, '1');
INSERT INTO menu_item_accesos VALUES (6, 12, 6, '1');
INSERT INTO menu_item_accesos VALUES (1, 1, 1, '2');
INSERT INTO menu_item_accesos VALUES (1, 1, 2, '2');
INSERT INTO menu_item_accesos VALUES (1, 1, 3, '2');
INSERT INTO menu_item_accesos VALUES (1, 1, 4, '2');
INSERT INTO menu_item_accesos VALUES (1, 1, 5, '2');
INSERT INTO menu_item_accesos VALUES (1, 1, 6, '2');
INSERT INTO menu_item_accesos VALUES (6, 13, 1, '1');
INSERT INTO menu_item_accesos VALUES (6, 13, 2, '1');
INSERT INTO menu_item_accesos VALUES (6, 13, 3, '1');
INSERT INTO menu_item_accesos VALUES (6, 13, 4, '1');
INSERT INTO menu_item_accesos VALUES (6, 13, 5, '1');
INSERT INTO menu_item_accesos VALUES (5, 9, 1, '2');
INSERT INTO menu_item_accesos VALUES (5, 9, 2, '2');
INSERT INTO menu_item_accesos VALUES (5, 9, 3, '2');
INSERT INTO menu_item_accesos VALUES (5, 9, 4, '2');
INSERT INTO menu_item_accesos VALUES (5, 9, 5, '2');
INSERT INTO menu_item_accesos VALUES (5, 9, 6, '2');
INSERT INTO menu_item_accesos VALUES (2, 4, 1, '2');
INSERT INTO menu_item_accesos VALUES (2, 4, 2, '2');
INSERT INTO menu_item_accesos VALUES (2, 4, 3, '2');
INSERT INTO menu_item_accesos VALUES (2, 4, 4, '2');
INSERT INTO menu_item_accesos VALUES (2, 4, 5, '2');
INSERT INTO menu_item_accesos VALUES (2, 4, 6, '2');


--
-- Data for Name: pregunta; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO pregunta VALUES (17, '<p>El p&uacute;blico objetivo incluye:</p>
', 22, 'Género.', 'Estado civil.', 'Hobbies.', 'Todas las anteriores.', 'Todas las anteriores.');
INSERT INTO pregunta VALUES (37, '<p>Display advertising es publicidad en sitios web que incluyen:</p>
', 22, 'Imágenes y audio.', 'Imágenes, texto, flash, video y audio.', 'Imágenes, flash, video y audio.', 'Imágenes y video.', 'Imágenes, texto, flash, video y audio.');
INSERT INTO pregunta VALUES (39, '<p>Este tipo de marketing premia a los clientes existentes o defensores de la marca por cada visitante o compra adquirida por sus esfuerzos de marketing.</p>
', 22, 'Associate marketing.', 'Appeal marketing.', 'Affiliate marketing.', 'Reliable marketing.', 'Affiliate marketing.');
INSERT INTO pregunta VALUES (35, '<p>El blog se usa en SEO para:</p>

<p>&nbsp;</p>
', 22, 'Obtener menos visitas en la página de inicio.', 'Aumentar el número de páginas.', 'Mantener el sitio web actualizado.', '', 'Mantener el sitio web actualizado.');
INSERT INTO pregunta VALUES (31, '<p>El m&eacute;todo de lead generation, puede hacer uso de la publicidad paga, pero tambi&eacute;n puede incluir:</p>
', 22, 'Búsqueda orgánica.', ' Referencias.', 'Resultados del motor.', 'Todas las anteriores.', 'Todas las anteriores.');
INSERT INTO pregunta VALUES (27, '<p>El proceso de content curation consiste en:</p>

<p>&nbsp;</p>
', 22, 'Comprar el contenido deseado, organizarlo y promocionarlo.', 'Descubrir el mejor contenido, organizarlo, contextualizarlo y promocionarlo.', 'Escribir el contenido, agregar imágenes y promocionarlo.', 'Ninguna de las anteriores.', 'Ninguna de las anteriores.');
INSERT INTO pregunta VALUES (15, '<p>&iquest;Cu&aacute;l es el viaje correcto del cliente?</p>
', 22, 'Awareness, interest, consideration, consumption, retention, advocacy.', 'Interest, awareness, consideration, purchase, retention, advocacy.', 'Awareness, interest, consideration, purchase, retention, advocacy.', 'Awareness, interest, consideration, consumption, advocacy.', 'Awareness, interest, consideration, consumption, advocacy.');
INSERT INTO pregunta VALUES (28, '<p>Estos se consideran offline marketing:</p>
', 22, 'POS, brochures, exhibitions.', 'Magazines, video, POS.', 'Social media, reviews, print.', 'Video, sales promotions, apps.', 'Video, sales promotions, apps.');
INSERT INTO pregunta VALUES (12, '<p>La b&uacute;squeda pagada y los anuncios de banner est&aacute;n configurados en:</p>
', 22, 'Hootsuite.', 'Google Adwords.', 'Google Analytics.', 'Bing.', 'Google Adwords.');
INSERT INTO pregunta VALUES (36, '<p>PPC significa que los anunciantes pagan cada vez que un usuario:</p>
', 22, 'Ver el anuncio.', 'Convierte.', 'Compra el producto.', 'Hace clic a un anuncio.', 'Hace clic a un anuncio.');
INSERT INTO pregunta VALUES (14, '<p>&iquest;C&oacute;mo re&uacute;nes la informaci&oacute;n de una buyer persona?</p>

<p>1 Investigaci&oacute;n de mercado.&nbsp;</p>

<p>2 P&aacute;ginas amarillas.</p>

<p>3 Ambiente de trabajo.&nbsp;</p>
', 22, '1 y 3.', '2 y 3.', '1 y 2.', '', '1 y 2.');
INSERT INTO pregunta VALUES (11, '<p>El marketing digital incluye:</p>

<p>&nbsp;</p>
', 22, '1 Display advertising.', '2 Vallas publicitarias.', '3 Email marketing.', '1 y 3.', '1 y 3.');
INSERT INTO pregunta VALUES (16, '<p>La propuesta de valor hace parte de:</p>
', 22, 'Modelo de negocios canvas.', 'Estrategia de medios digitales.', 'Modelo de ventas canvas.', 'Modelo en línea canvas.', 'Modelo en línea canvas.');
INSERT INTO pregunta VALUES (13, '<p>Una buyer persona incluye:</p>
', 22, 'Hábitos de compra.', 'Ingresos del hogar.', 'Posición y título.', 'Todas las anteriores.', 'Todas las anteriores.');
INSERT INTO pregunta VALUES (33, '<p>SEM significa:</p>

<p>&nbsp;</p>
', 22, 'Search engine marketing.', 'Search engagement marketing.', 'Sender email marketing.', 'Smarketing engine mobile.', 'Search engine marketing.');
INSERT INTO pregunta VALUES (40, '<p>Los objetivos del email marketing incluyen:</p>
', 22, 'Vender productos/servicios.', 'Generate leads.', 'Dar apogo.', 'Todas las anteriores.', 'Todas las anteriores.');
INSERT INTO pregunta VALUES (18, '<p>Los comentarios hacen parte de:</p>
', 22, 'Etapa Retention.', 'Etapa Purchase.', 'Etapa Consideration.', 'Etapa Convert.', 'Etapa Convert.');
INSERT INTO pregunta VALUES (32, '<p>Antes de que los clientes potenciales se conviertan en clientes, deben seguir estos pasos:</p>
', 22, 'Warm prospects, leads, hot leads.', 'Interested prospects, warm leads, hot leads.', 'Hot prospects, leads, hot leads.', 'Ninguno de los anteriores.', 'Interested prospects, warm leads, hot leads.');
INSERT INTO pregunta VALUES (30, '<p>Sales funnel es tambi&eacute;n conocido como:</p>

<p>&nbsp;</p>
', 22, 'Embudo de pago.', 'Embudo de ingresos.', 'Embudo de entrada.', 'Embudo de pronósticos. ', 'Embudo de ingresos.');
INSERT INTO pregunta VALUES (21, '<p>Los blogs son una excelente forma de:</p>

<p>1. Promover nuevas ofertas.</p>

<p>2. Llevar a cabo estudios de mercado.</p>

<p>3. Compartir informaci&oacute;n nueva y emocionante.</p>
', 22, '1 y 3.', '1 y 2.', '2 y 3.', '', '2 y 3.');
INSERT INTO pregunta VALUES (25, '<p>Content curation no es:</p>
', 22, 'Nuevo contenido creado por una empresa.', 'Una compilación de los mejores blogs.', 'Infografías, artículos y publicaciones en redes sociales.', 'UGC (contenido generado por el usuario).', 'Nuevo contenido creado por una empresa.');
INSERT INTO pregunta VALUES (38, '<p>Redirect es un m&eacute;todo de redirigir a un visitante de una p&aacute;gina a otra p&aacute;gina web, que se usa&nbsp;solo para situaciones temporales.</p>
', 22, '404', '301', '403', '302', '302');
INSERT INTO pregunta VALUES (19, '<p>Content marketing a menudo se usa para:</p>
', 22, 'Generar o aumentar las ventas en línea.', 'Crear encuestas para reunir información de los clientes.', 'Recopila información personal del cliente, como ingresos, edad y datos demográficos.', 'Estudios de mercado.', 'Estudios de mercado.');
INSERT INTO pregunta VALUES (24, '<p>Inbound marketing est&aacute; compuesto por estos pasos:</p>
', 22, 'Awareness, convert, close y delight.', 'Attract, convert, close y nurture.', 'Attract, convert, close y delight.', 'Attract, interest, close y delight.', 'Attract, interest, close y delight.');
INSERT INTO pregunta VALUES (20, '<p>Blog es una combinaci&oacute;n de las palabras:</p>
', 22, 'Business y log.', 'Brand y log.', 'Web y log.', 'Video y log.', 'Web y log.');
INSERT INTO pregunta VALUES (10, '<p>El marketing digital tambi&eacute;n se conoce como:</p>
', 22, 'Mercadeo en línea.', 'Marketing impulsado por los datos.', 'Marketing basado en análisis de datos.', 'Website marketing.', 'Website marketing.');
INSERT INTO pregunta VALUES (51, '<p>Marketing digital _______ y _________ son valores utilizados por los equipos de marketing para medir y seguir el rendimiento de sus campa&ntilde;as de marketing:</p>
', 22, 'Revenue metrics. ', 'KPIs revenue. ', 'Sales metrics. ', 'Metrics KPIs. ', 'Metrics KPIs. ');
INSERT INTO pregunta VALUES (22, '<p>_________ es una t&eacute;cnica para atraer clientes, hacia productos y servicios a trav&eacute;s de content marketing, social media marketing, search engine optimization y branding:</p>
', 22, 'Outbound marketing.', 'Inbound marketing.', 'Digital marketing.', 'Incoming marketing.', 'Inbound marketing.');
INSERT INTO pregunta VALUES (55, '<p>Su equipo de marketing est&aacute; discutiendo las diferencias entre SEO y SEM. &iquest;Qu&eacute; miembro del equipo tiene raz&oacute;n?&nbsp;</p>
', 22, 'No hay diferencia. Ambos son lo mismo.', 'SEO es más white hat, SEM es más gris.', 'SEO se refiere a los resultados de búsqueda orgánica mientras que el SEM se enfoca en búsquedas paga. ', 'SEO se centra en las clasificaciones de búsqueda orgánica, mientras que SEM abarca todos los aspectos de marketing de búsquedas.', 'SEO se refiere a los resultados de búsqueda orgánica mientras que el SEM se enfoca en búsquedas paga.');
INSERT INTO pregunta VALUES (49, '<p>Para rastrear el comportamiento de un consumidor, se debe establecer un ______ en el navegador del usuario:</p>
', 22, 'Code.', 'Cookie.', 'Pixel.', 'Program.', 'Cokkie.');
INSERT INTO pregunta VALUES (45, '<p>_________ son tecnolog&iacute;as mediadas por computadora que facilitan la creaci&oacute;n y el intercambio de informaci&oacute;n, ideas, intereses de carrera y otras formas de expresi&oacute;n a trav&eacute;s de comunidades virtuales y redes.</p>
', 22, 'Blog.', 'Redes sociales.', 'Microsites.', 'Sitios web.', 'Redes sociales.');
INSERT INTO pregunta VALUES (48, '<p>Retargeting es una forma de publicidad en l&iacute;nea dirigida a los consumidores basada en:</p>
', 22, 'Buyer persona.', 'Nivel de ingreso.', 'Edad.', 'Acciones en línea.', 'Acciones en línea. ');
INSERT INTO pregunta VALUES (43, '<p>Para cumplir con la ley CAN-SPAM, debe incluir:</p>
', 22, 'Borre «de» y «para», revele claramente que su mensaje es publicitario, tenga la opción y haga  que sea fácil optar por no participar, respete las exclusiones en 10 días, no use lenguaje  engañoso, asegúrese de que todas las empresas cumplan.', 'La ley CAN-SPAM solo se aplica a los correos electrónicos que se enviaron antes de 2003.', 'Dirección postal válida, borre «de» y «a», revele claramente que su mensaje es publicitario, tenga la opción y haga que sea fácil optar por no participar, respete las exclusiones en 10 días, no use lenguaje engañoso, asegúrese de que todas las firmas estén en conformidad.', '«De» y «para», dirección postal válida y opción de exclusión.', 'Dirección postal válida, borre «de» y «a», revele claramente que su mensaje es publicitario, tenga la opción y haga que sea fácil optar por no participar, respete las exclusiones en 10 días, no use lenguaje engañoso, asegúrese de que todas las firmas estén en conformidad.');
INSERT INTO pregunta VALUES (52, '<p>Esto se considera un KPI digital:</p>
', 22, 'Household income. ', 'CTR. ', 'Purchase history', 'CTP. ', 'CTR. ');
INSERT INTO pregunta VALUES (47, '<p>Behavioral retargeting tambi&eacute;n se conoce como:</p>
', 22, '1 Action retargeting.', '2 Behavioral remarkehing.', '3 Retargeting.', '1 y 3.', '1 y 3.');
INSERT INTO pregunta VALUES (50, '<p>Esta t&eacute;cnica es utilizada por los vendedores para mostrar publicidad a las personas que han visitado previamente su sitio web.</p>
', 22, 'Website retargeting.', 'Webpage retargeting.', 'Site retargeting.', 'User retargeting.', 'Site retargeting.');
INSERT INTO pregunta VALUES (54, '<p>Inboud marketing est&aacute; compuesto por cuatro pasos. Calls to actions, landing pages y los formularios de informaci&oacute;n, hacen parte de la etapa____________.&nbsp;</p>
', 22, 'Convertir.', 'Adaptación.', 'Crecimiento.', 'Persuadir.', 'Convertir.');
INSERT INTO pregunta VALUES (41, '<p>Las listas de correo electr&oacute;nico se pueden segmentar por:</p>
', 22, 'Edad, sexo, compañía.', 'Cualquier cantidad de condiciones.', 'Productos comprados.', 'Título, ingreso familiar, edad.', 'Cualquier cantidad de condiciones.');
INSERT INTO pregunta VALUES (44, '<p>La estrategia de comunicaci&oacute;n que env&iacute;a un conjunto de mensajes previamente escritos a clientes o prospectos tambi&eacute;n se conoce como:</p>
', 22, 'Automation marketing.', 'Dynamic marketing.', 'Pre-sec campaings.', 'Drip marketing.', 'Drip marketing.');
INSERT INTO pregunta VALUES (34, '<p>SEO o Search engine optimization es el proceso de:</p>
', 22, 'Optimizar la visibilidad en línea de un sitio web o página web en los resultados pagos de un  motor de búsqueda.', 'Optimizar la visibilidad en línea de un sitio web o página web en los resultados impagos de  un motor de búsqueda.', 'Optimizar la visibilidad en línea de una página web solo en los resultados pagos de un  motor de búsqueda.', 'Aumentar la cantidad y la calidad del tráfico a su sitio web a través de publicidad pagada.', 'Optimizar la visibilidad en línea de un sitio web o página web en los resultados impagos de  un motor de búsqueda.');
INSERT INTO pregunta VALUES (46, '<p>Existen diferentes tipos de retargeting: Advertiser, creative, reverse y:</p>
', 22, 'Sponsorship.', 'Support.', 'Innovating.', 'Sales.', 'Sponsorship.');
INSERT INTO pregunta VALUES (42, '<p>La capacidad de enviar correos electr&oacute;nicos a las bandejas de entrada de los suscriptores se&nbsp;conoce como:</p>
', 22, 'Capacidad de entrega.', 'Email enviado.', 'Ejecución de campaña.', 'Implementación de correo electrónico.', 'Capacidad de entrega.');
INSERT INTO pregunta VALUES (64, '<p>Le gustar&iacute;a comenzar a implementar Affiliate marketing &iquest;C&oacute;mo deber&iacute;a pagarle a tu blogger?&nbsp;</p>
', 22, 'Por cada compra que se hace a través de su blog.', 'Por cada visitante que recibe en su blog.', 'Por cada registro que recibes de su blog.', 'Depende de lo que Haya acordado con el blogger.', 'Por cada compra que se hace a través de su blog.');
INSERT INTO pregunta VALUES (67, '<p>Usted ha sido invitado a la reuni&oacute;n semanal de ventas. En la reuni&oacute;n el equipo de ventas le pide que los apoye en la etapa de inter&eacute;s para que los clientes puedan realizar una acci&oacute;n. El equipo de ventas se refiere a:</p>

<p>&nbsp;</p>
', 22, 'Pay funnel.', 'Income funnel.', 'Revenue funnel.', 'Forecasting funnel.', 'Pay funnel.');
INSERT INTO pregunta VALUES (61, '<p>&iquest;Una landing page es la p&aacute;gina que los usuarios ven luego de hacer clic en un anuncio?&nbsp;</p>
', 22, 'Verdadero.', 'Falso.', '', '', 'Verdadero.');
INSERT INTO pregunta VALUES (68, '<p>Como parte de sus nuevas funciones como Director de marketing, se le ha entregado la propuesta de valor de la empresa para presentarla a los miembros de la junta. En la reuni&oacute;n uno de ellos le pregunta en qu&eacute; parte se encuentra la propuesta de valor y usted responde.&nbsp;</p>
', 22, 'Modelo de ventas canvas.', 'Modelo de negocio canvas.', 'Estrategia de medios digitales.', 'Modelo en línea canvas.', 'Modelo de negocio canvas.');
INSERT INTO pregunta VALUES (57, '<p>Tiene la tarea de crear actividades para mejorar el viaje del cliente en el marketing digital en la etapa de inter&eacute;s. &iquest;Cu&aacute;l de los siguientes considerar&iacute;a implementar?&nbsp;</p>

<p>1 PPC</p>

<p>2 Radio</p>

<p>3 Voz a voz</p>

<p>4 Email</p>

<p>&nbsp;</p>
', 22, '1, 3 y 4.', '1 y 2.', '4 y 1.', '1, 2 y 4.', '1, 3 y 4.');
INSERT INTO pregunta VALUES (65, '<p>Se le ha pedido atraer atenci&oacute;n y generar clientes potenciales por medio del negocio digital. &iquest;Qu&eacute; considerar&iacute;as implementar?&nbsp;</p>

<p>&nbsp;</p>
', 22, 'Comerciales de radio.', 'Gran apertura en productos gratis.', 'Content marketing.', 'Lanzamiento de sitio e-commerce.', 'Content marketing.');
INSERT INTO pregunta VALUES (78, '<p>Los enlaces de exclusi&oacute;n son siempre opcionales:</p>
', 22, 'Verdadero.', 'Falso.', '', '', 'Verdadero.');
INSERT INTO pregunta VALUES (69, '<p>El marketing basado en datos tambi&eacute;n se conoce como:</p>
', 22, 'Data analytics marketing.', 'Online marketing.', 'Marketing digital.', 'Website marketing.', 'Data analytics marketing.');
INSERT INTO pregunta VALUES (77, '<p>Con el fin de apoyar al equipo de ventas, usted est&aacute; solicitando un aumento en su presupuesto digital, para centrarse en m&eacute;todos pagados de lead generation. &iquest;En qu&eacute; m&eacute;todos debes invertir?&nbsp;</p>
', 22, 'PPC.', 'Referencias.', 'Búsqueda orgánica.', 'Resultados del motor.', 'PPC.');
INSERT INTO pregunta VALUES (63, '<p>&iquest;Para qu&eacute; usar&iacute;as SEO?&nbsp;</p>
', 22, 'Una forma de aumentar el tráfico en su sitio web.', 'Un proceso para mejorar la visibilidad de su sitio web en los motores de búsqueda.', 'Un lenguaje de codificación.', 'Ninguno de los anteriores.', 'Un proceso para mejorar la visibilidad de su sitio web en los motores de búsqueda.');
INSERT INTO pregunta VALUES (79, '<p>Est&aacute;s luchando con la construcci&oacute;n de enlaces para SEO. &iquest;Que puede ayudar a que sitio web tenga un ranking m&aacute;s alto?&nbsp;</p>
', 22, 'Publicaciones en redes sociales.', 'Un blog.', 'Email.', 'PPC.', 'Un blog.');
INSERT INTO pregunta VALUES (60, '<p>Est&aacute; discutiendo el seguimiento del comportamiento del cliente con su especialista en marketing y est&aacute; confundido en cu&aacute;nto a lo que debe hacerse. Le dices que un cookie debe establecerse en el_____________del usuario.&nbsp;</p>
', 22, 'Computador.', 'Navegador.', 'Teléfono.', 'Perfil.', 'Navegador.');
INSERT INTO pregunta VALUES (58, '<p>Usted ha estado estudiando el recorrido del cliente y le gustar&iacute;a enviar un conjunto de mensajes previamente escritos a los clientes. &iquest;En qu&eacute; estrategia de comunicaci&oacute;n deber&iacute;as empezar a trabajar?&nbsp;</p>
', 22, 'Campañas preestablecidas.', 'Drip marketing.', 'Automatización de marketing.', 'Marketing dinámico.', 'Drip marketing.');
INSERT INTO pregunta VALUES (66, '<p>El objetivo principal de una campa&ntilde;a de Display, es generar clientes potenciales para el cliente.&nbsp;</p>
', 22, 'Verdadero.', 'Falso.', '', '', 'Verdadero.');
INSERT INTO pregunta VALUES (59, '<p>&iquest;Las vallas publicitarias y el email marketing son parte del marketing digital?&nbsp;</p>
', 22, 'Verdadero.', 'Falso.', '', '', 'Falso.');
INSERT INTO pregunta VALUES (73, '<p>&iquest;Cu&aacute;les son ejemplos de redes sociales?&nbsp;</p>
', 22, 'Poscasting.', 'Blogs.', 'Facebook, linkedin.', 'Wiki.', 'Facebook, linkedin.');
INSERT INTO pregunta VALUES (70, '<p>En general cu&aacute;nto m&aacute;s de su publicidad aparezca, m&aacute;s d&iacute;as obtendr&aacute; y m&aacute;s ________________________.&nbsp;</p>
', 22, 'Hace que los usuarios visiten su sitio web.', 'Convertir.', 'Venta.', 'Paga.', 'Hace que los usuarios visiten su sitio web.');
INSERT INTO pregunta VALUES (76, '<p>Como parte de su estrategia de marketing digital, debes implementar el inbound marketing. &iquest;En qu&eacute; puedes confiar?&nbsp;</p>
', 22, '1 Blogs.', '2 Redes sociales.', '3 Motores de búsqueda.', '1, 2 y 3.', '1, 2 y 3.');
INSERT INTO pregunta VALUES (74, '<p>Se le ha proporcionado la base de datos de correo electr&oacute;nico de su empresa. &iquest;C&oacute;mo puede segmentarlo?</p>

<p>1 Por g&eacute;nero.&nbsp;</p>

<p>2 Por productos comprados.&nbsp;</p>

<p>3 Por ingreso familiar.&nbsp;</p>
', 22, '1 y 2.', '1.', '2 y 3.', '', '1 y 2.');
INSERT INTO pregunta VALUES (72, '<p>Ha estado trabajando en el viaje del cliente en el marketing digital. Usted sabe que comienza con awareness, interest, ____________, purchase, retention y ad vocacy. &iquest;Qu&eacute; paso te est&aacute;s perdiendo?&nbsp;</p>
', 22, 'Consumption.', 'Interest.', 'Contemplation.', 'Consideration.', 'Consideration.');
INSERT INTO pregunta VALUES (75, '<p>Como Director de marketing, le gustar&iacute;a que su sitio web sea m&aacute;s visible para las personas sin gastar dinero. &iquest;Qu&eacute; m&eacute;todo deber&iacute;a usar?&nbsp;</p>
', 22, 'PPC.', 'Blogs.', 'Social media.', 'SEM.', 'Blogs.');
INSERT INTO pregunta VALUES (62, '<p>Te est&aacute;s preparando para enviar tu primera campa&ntilde;a de correo electr&oacute;nico. &iquest;Cu&aacute;l de los siguientes puede da&ntilde;ar su capacidad de entrega?&nbsp;</p>

<p>1 Env&iacute;o de correo electr&oacute;nico sin autenticaci&oacute;n personalizada.&nbsp;</p>

<p>2 Usar la opci&oacute;n de suscripci&oacute;n &uacute;nica.&nbsp;</p>

<p>3 Uso de URL shorteners.&nbsp;</p>

<p>4 Versi&oacute;n del texto.&nbsp;</p>
', 22, '1 y 3.', '1, 3 y 4.', '1, 2 y 3.', '1 y 2.', '1, 2 y 3.');
INSERT INTO pregunta VALUES (71, '<p>El &aacute;rbol de marketing en Internet est&aacute; compuesto por:</p>
', 22, 'SEM, directories and listing, email marketing, social marketing, PR, online advertising, website.', 'SEM, directories and listing, email marketing, social marketing, PR, online advertising.', 'SEM, free listings, email marketing, social networks, press reléase, ad networks, website.', 'SEO, directories and listing, email, social networks, PR, online advertising.', 'SEM, directories and listing, email marketing, social marketing, PR, online advertising, website.');


--
-- Data for Name: promedio; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO promedio VALUES (33, 67.5, 'Aprobado', '44643430');
INSERT INTO promedio VALUES (34, 37.5, 'Desaprobado', '78998521');
INSERT INTO promedio VALUES (35, 60, 'Aprobado', '71407684');
INSERT INTO promedio VALUES (36, 60, 'Aprobado', '76407327');
INSERT INTO promedio VALUES (37, 65, 'Aprobado', '70184250');


--
-- Data for Name: prueba; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO prueba VALUES (22, '40', '40', 60, 22);
INSERT INTO prueba VALUES (2, '10', '10', 10, 2);


--
-- Data for Name: respuesta_pregunta_usuario; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO respuesta_pregunta_usuario VALUES (6607, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '4');
INSERT INTO respuesta_pregunta_usuario VALUES (6608, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '5');
INSERT INTO respuesta_pregunta_usuario VALUES (6609, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '6');
INSERT INTO respuesta_pregunta_usuario VALUES (6610, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '7');
INSERT INTO respuesta_pregunta_usuario VALUES (6611, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '8');
INSERT INTO respuesta_pregunta_usuario VALUES (6612, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '9');
INSERT INTO respuesta_pregunta_usuario VALUES (5476, '1 y 3.', 1, 'Correcto', 11, '44643430', 33, 'Si', '39');
INSERT INTO respuesta_pregunta_usuario VALUES (6613, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '10');
INSERT INTO respuesta_pregunta_usuario VALUES (6614, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '11');
INSERT INTO respuesta_pregunta_usuario VALUES (5593, 'Email enviado.', 0, 'Incorrecto', 42, '78998521', 34, 'Si', '35');
INSERT INTO respuesta_pregunta_usuario VALUES (6615, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '12');
INSERT INTO respuesta_pregunta_usuario VALUES (6616, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '13');
INSERT INTO respuesta_pregunta_usuario VALUES (7507, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '2');
INSERT INTO respuesta_pregunta_usuario VALUES (6617, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '14');
INSERT INTO respuesta_pregunta_usuario VALUES (6618, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '15');
INSERT INTO respuesta_pregunta_usuario VALUES (6619, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '16');
INSERT INTO respuesta_pregunta_usuario VALUES (6620, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '17');
INSERT INTO respuesta_pregunta_usuario VALUES (6621, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '18');
INSERT INTO respuesta_pregunta_usuario VALUES (6622, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '19');
INSERT INTO respuesta_pregunta_usuario VALUES (6623, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '20');
INSERT INTO respuesta_pregunta_usuario VALUES (6624, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '21');
INSERT INTO respuesta_pregunta_usuario VALUES (6625, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '22');
INSERT INTO respuesta_pregunta_usuario VALUES (6626, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '23');
INSERT INTO respuesta_pregunta_usuario VALUES (5549, 'Buyer persona.', 0, 'Incorrecto', 48, '71407684', 35, 'Si', '32');
INSERT INTO respuesta_pregunta_usuario VALUES (6627, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '24');
INSERT INTO respuesta_pregunta_usuario VALUES (5550, '2 y 3.', 0, 'Incorrecto', 74, '71407684', 35, 'Si', '33');
INSERT INTO respuesta_pregunta_usuario VALUES (5553, 'Redes sociales.', 1, 'Correcto', 45, '71407684', 35, 'Si', '36');
INSERT INTO respuesta_pregunta_usuario VALUES (6628, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '25');
INSERT INTO respuesta_pregunta_usuario VALUES (5552, 'Social media.', 0, 'Incorrecto', 75, '71407684', 35, 'Si', '35');
INSERT INTO respuesta_pregunta_usuario VALUES (6629, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '26');
INSERT INTO respuesta_pregunta_usuario VALUES (5554, '1 y 3.', 1, 'Correcto', 11, '71407684', 35, 'Si', '37');
INSERT INTO respuesta_pregunta_usuario VALUES (6630, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '27');
INSERT INTO respuesta_pregunta_usuario VALUES (6631, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '28');
INSERT INTO respuesta_pregunta_usuario VALUES (6632, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '29');
INSERT INTO respuesta_pregunta_usuario VALUES (5555, 'Web y log.', 1, 'Correcto', 20, '71407684', 35, 'Si', '38');
INSERT INTO respuesta_pregunta_usuario VALUES (6633, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '30');
INSERT INTO respuesta_pregunta_usuario VALUES (5556, 'Interested prospects, warm leads, hot leads.', 1, 'Correcto', 32, '71407684', 35, 'Si', '39');
INSERT INTO respuesta_pregunta_usuario VALUES (5626, 'Facebook, linkedin.', 1, 'Correcto', 73, '70184250', 37, 'Si', '28');
INSERT INTO respuesta_pregunta_usuario VALUES (5600, 'falta', 0, 'Incorrecto', 35, '70184250', 37, 'Si', '2');
INSERT INTO respuesta_pregunta_usuario VALUES (6634, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '31');
INSERT INTO respuesta_pregunta_usuario VALUES (5557, 'Todas las anteriores.', 1, 'Correcto', 17, '71407684', 35, 'Si', '40');
INSERT INTO respuesta_pregunta_usuario VALUES (5602, 'Un blog.', 1, 'Correcto', 79, '70184250', 37, 'Si', '4');
INSERT INTO respuesta_pregunta_usuario VALUES (5519, '1, 3 y 4.', 1, 'Correcto', 57, '71407684', 35, 'Si', '2');
INSERT INTO respuesta_pregunta_usuario VALUES (5604, '1 y 3.', 0, 'Incorrecto', 14, '70184250', 37, 'Si', '6');
INSERT INTO respuesta_pregunta_usuario VALUES (5521, 'Content marketing.', 1, 'Correcto', 65, '71407684', 35, 'Si', '4');
INSERT INTO respuesta_pregunta_usuario VALUES (5606, 'Navegador.', 1, 'Correcto', 60, '70184250', 37, 'Si', '8');
INSERT INTO respuesta_pregunta_usuario VALUES (5522, 'Todas las anteriores.', 1, 'Correcto', 31, '71407684', 35, 'Si', '5');
INSERT INTO respuesta_pregunta_usuario VALUES (5528, 'Income funnel.', 0, 'Incorrecto', 67, '71407684', 35, 'Si', '11');
INSERT INTO respuesta_pregunta_usuario VALUES (5607, 'Marketing digital.', 0, 'Incorrecto', 69, '70184250', 37, 'Si', '9');
INSERT INTO respuesta_pregunta_usuario VALUES (6635, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '32');
INSERT INTO respuesta_pregunta_usuario VALUES (5608, '1, 2 y 3.', 1, 'Correcto', 76, '70184250', 37, 'Si', '10');
INSERT INTO respuesta_pregunta_usuario VALUES (6636, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '33');
INSERT INTO respuesta_pregunta_usuario VALUES (6637, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '34');
INSERT INTO respuesta_pregunta_usuario VALUES (6638, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '35');
INSERT INTO respuesta_pregunta_usuario VALUES (6639, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '36');
INSERT INTO respuesta_pregunta_usuario VALUES (6640, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '37');
INSERT INTO respuesta_pregunta_usuario VALUES (6641, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '38');
INSERT INTO respuesta_pregunta_usuario VALUES (6642, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '39');
INSERT INTO respuesta_pregunta_usuario VALUES (6643, 'falta', NULL, NULL, NULL, '47412369', NULL, NULL, '40');
INSERT INTO respuesta_pregunta_usuario VALUES (7508, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '3');
INSERT INTO respuesta_pregunta_usuario VALUES (7509, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '4');
INSERT INTO respuesta_pregunta_usuario VALUES (7510, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '5');
INSERT INTO respuesta_pregunta_usuario VALUES (7511, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '6');
INSERT INTO respuesta_pregunta_usuario VALUES (7512, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '7');
INSERT INTO respuesta_pregunta_usuario VALUES (7513, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '8');
INSERT INTO respuesta_pregunta_usuario VALUES (7514, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '9');
INSERT INTO respuesta_pregunta_usuario VALUES (7515, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '10');
INSERT INTO respuesta_pregunta_usuario VALUES (7516, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '11');
INSERT INTO respuesta_pregunta_usuario VALUES (7517, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '12');
INSERT INTO respuesta_pregunta_usuario VALUES (7518, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '13');
INSERT INTO respuesta_pregunta_usuario VALUES (7519, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '14');
INSERT INTO respuesta_pregunta_usuario VALUES (7520, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '15');
INSERT INTO respuesta_pregunta_usuario VALUES (6605, 'Falso.', 0, 'Incorrecto', 61, '47412369', NULL, NULL, '2');
INSERT INTO respuesta_pregunta_usuario VALUES (6606, 'Falso.', 1, 'Correcto', 59, '47412369', NULL, NULL, '3');
INSERT INTO respuesta_pregunta_usuario VALUES (6604, 'Referencias.', 0, 'Incorrecto', 77, '47412369', NULL, NULL, '1');
INSERT INTO respuesta_pregunta_usuario VALUES (7521, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '16');
INSERT INTO respuesta_pregunta_usuario VALUES (7522, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '17');
INSERT INTO respuesta_pregunta_usuario VALUES (7523, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '18');
INSERT INTO respuesta_pregunta_usuario VALUES (7524, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '19');
INSERT INTO respuesta_pregunta_usuario VALUES (7525, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '20');
INSERT INTO respuesta_pregunta_usuario VALUES (7526, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '21');
INSERT INTO respuesta_pregunta_usuario VALUES (7527, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '22');
INSERT INTO respuesta_pregunta_usuario VALUES (7528, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '23');
INSERT INTO respuesta_pregunta_usuario VALUES (7529, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '24');
INSERT INTO respuesta_pregunta_usuario VALUES (7530, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '25');
INSERT INTO respuesta_pregunta_usuario VALUES (7531, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '26');
INSERT INTO respuesta_pregunta_usuario VALUES (7532, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '27');
INSERT INTO respuesta_pregunta_usuario VALUES (7533, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '28');
INSERT INTO respuesta_pregunta_usuario VALUES (7534, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '29');
INSERT INTO respuesta_pregunta_usuario VALUES (7535, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '30');
INSERT INTO respuesta_pregunta_usuario VALUES (7536, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '31');
INSERT INTO respuesta_pregunta_usuario VALUES (7537, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '32');
INSERT INTO respuesta_pregunta_usuario VALUES (7538, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '33');
INSERT INTO respuesta_pregunta_usuario VALUES (7539, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '34');
INSERT INTO respuesta_pregunta_usuario VALUES (7540, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '35');
INSERT INTO respuesta_pregunta_usuario VALUES (7541, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '36');
INSERT INTO respuesta_pregunta_usuario VALUES (7542, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '37');
INSERT INTO respuesta_pregunta_usuario VALUES (7543, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '38');
INSERT INTO respuesta_pregunta_usuario VALUES (7544, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '39');
INSERT INTO respuesta_pregunta_usuario VALUES (7545, 'falta', NULL, NULL, NULL, '70464700', NULL, NULL, '40');
INSERT INTO respuesta_pregunta_usuario VALUES (7506, 'Imágenes y video.', 0, 'Incorrecto', 37, '70464700', NULL, NULL, '1');
INSERT INTO respuesta_pregunta_usuario VALUES (7261, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '1');
INSERT INTO respuesta_pregunta_usuario VALUES (7262, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '2');
INSERT INTO respuesta_pregunta_usuario VALUES (7263, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '3');
INSERT INTO respuesta_pregunta_usuario VALUES (7264, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '4');
INSERT INTO respuesta_pregunta_usuario VALUES (7265, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '5');
INSERT INTO respuesta_pregunta_usuario VALUES (5473, '1, 2 y 3.', 1, 'Correcto', 76, '44643430', 33, 'Si', '36');
INSERT INTO respuesta_pregunta_usuario VALUES (7266, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '6');
INSERT INTO respuesta_pregunta_usuario VALUES (5424, 'Web y log.', 1, 'Correcto', 20, '76407327', 36, 'Si', '29');
INSERT INTO respuesta_pregunta_usuario VALUES (5591, 'Productos comprados.', 0, 'Incorrecto', 41, '78998521', 34, 'Si', '33');
INSERT INTO respuesta_pregunta_usuario VALUES (7267, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '7');
INSERT INTO respuesta_pregunta_usuario VALUES (5435, 'falta', 0, 'Incorrecto', 10, '76407327', 36, 'Si', '40');
INSERT INTO respuesta_pregunta_usuario VALUES (5427, 'Ninguno de los anteriores.', 0, 'Incorrecto', 32, '76407327', 36, 'Si', '32');
INSERT INTO respuesta_pregunta_usuario VALUES (5429, 'Verdadero.', 1, 'Correcto', 61, '76407327', 36, 'Si', '34');
INSERT INTO respuesta_pregunta_usuario VALUES (7268, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '8');
INSERT INTO respuesta_pregunta_usuario VALUES (7269, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '9');
INSERT INTO respuesta_pregunta_usuario VALUES (5430, 'Drip marketing.', 1, 'Correcto', 58, '76407327', 36, 'Si', '35');
INSERT INTO respuesta_pregunta_usuario VALUES (7270, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '10');
INSERT INTO respuesta_pregunta_usuario VALUES (7271, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '11');
INSERT INTO respuesta_pregunta_usuario VALUES (7272, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '12');
INSERT INTO respuesta_pregunta_usuario VALUES (7273, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '13');
INSERT INTO respuesta_pregunta_usuario VALUES (7274, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '14');
INSERT INTO respuesta_pregunta_usuario VALUES (7275, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '15');
INSERT INTO respuesta_pregunta_usuario VALUES (7276, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '16');
INSERT INTO respuesta_pregunta_usuario VALUES (7277, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '17');
INSERT INTO respuesta_pregunta_usuario VALUES (7278, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '18');
INSERT INTO respuesta_pregunta_usuario VALUES (7279, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '19');
INSERT INTO respuesta_pregunta_usuario VALUES (7280, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '20');
INSERT INTO respuesta_pregunta_usuario VALUES (7281, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '21');
INSERT INTO respuesta_pregunta_usuario VALUES (7282, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '22');
INSERT INTO respuesta_pregunta_usuario VALUES (7283, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '23');
INSERT INTO respuesta_pregunta_usuario VALUES (7284, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '24');
INSERT INTO respuesta_pregunta_usuario VALUES (7285, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '25');
INSERT INTO respuesta_pregunta_usuario VALUES (7286, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '26');
INSERT INTO respuesta_pregunta_usuario VALUES (7287, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '27');
INSERT INTO respuesta_pregunta_usuario VALUES (7288, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '28');
INSERT INTO respuesta_pregunta_usuario VALUES (7289, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '29');
INSERT INTO respuesta_pregunta_usuario VALUES (7290, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '30');
INSERT INTO respuesta_pregunta_usuario VALUES (7291, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '31');
INSERT INTO respuesta_pregunta_usuario VALUES (7292, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '32');
INSERT INTO respuesta_pregunta_usuario VALUES (7293, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '33');
INSERT INTO respuesta_pregunta_usuario VALUES (7294, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '34');
INSERT INTO respuesta_pregunta_usuario VALUES (7295, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '35');
INSERT INTO respuesta_pregunta_usuario VALUES (7296, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '36');
INSERT INTO respuesta_pregunta_usuario VALUES (7297, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '37');
INSERT INTO respuesta_pregunta_usuario VALUES (7298, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '38');
INSERT INTO respuesta_pregunta_usuario VALUES (7299, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '39');
INSERT INTO respuesta_pregunta_usuario VALUES (7300, 'falta', NULL, NULL, NULL, '45977448', NULL, NULL, '40');
INSERT INTO respuesta_pregunta_usuario VALUES (5628, 'Content marketing.', 1, 'Correcto', 65, '70184250', 37, 'Si', '30');
INSERT INTO respuesta_pregunta_usuario VALUES (5612, 'Web y log.', 1, 'Correcto', 20, '70184250', 37, 'Si', '14');
INSERT INTO respuesta_pregunta_usuario VALUES (5611, 'Magazines, video, POS.', 0, 'Incorrecto', 28, '70184250', 37, 'Si', '13');
INSERT INTO respuesta_pregunta_usuario VALUES (5613, 'PPC.', 1, 'Correcto', 77, '70184250', 37, 'Si', '15');
INSERT INTO respuesta_pregunta_usuario VALUES (5617, 'CTR. ', 1, 'Correcto', 52, '70184250', 37, 'Si', '19');
INSERT INTO respuesta_pregunta_usuario VALUES (5398, 'Hace que los usuarios visiten su sitio web.', 1, 'Correcto', 70, '76407327', 36, 'Si', '3');
INSERT INTO respuesta_pregunta_usuario VALUES (5618, 'Hace clic a un anuncio.', 1, 'Correcto', 36, '70184250', 37, 'Si', '20');
INSERT INTO respuesta_pregunta_usuario VALUES (5431, 'Google Adwords.', 0, 'Incorrecto', 12, '76407327', 36, 'Si', '36');
INSERT INTO respuesta_pregunta_usuario VALUES (5432, 'Cookie.', 0, 'Incorrecto', 49, '76407327', 36, 'Si', '37');
INSERT INTO respuesta_pregunta_usuario VALUES (5433, 'Dirección postal válida, borre «de» y «a», revele claramente que su mensaje es publicitario, tenga la opción y haga que sea fácil optar por no participar, respete las exclusiones en 10 días, no use lenguaje engañoso, asegúrese de que todas las firmas estén en conformidad.', 1, 'Correcto', 43, '76407327', 36, 'Si', '38');
INSERT INTO respuesta_pregunta_usuario VALUES (5434, 'Awareness, interest, consideration, purchase, retention, advocacy.', 0, 'Incorrecto', 15, '76407327', 36, 'Si', '39');
INSERT INTO respuesta_pregunta_usuario VALUES (5396, 'Título, ingreso familiar, edad.', 0, 'Incorrecto', 41, '76407327', 36, 'Si', '1');
INSERT INTO respuesta_pregunta_usuario VALUES (5397, 'Facebook, linkedin.', 1, 'Correcto', 73, '76407327', 36, 'Si', '2');
INSERT INTO respuesta_pregunta_usuario VALUES (5400, 'Verdadero.', 1, 'Correcto', 66, '76407327', 36, 'Si', '5');
INSERT INTO respuesta_pregunta_usuario VALUES (5404, 'Redes sociales.', 1, 'Correcto', 45, '76407327', 36, 'Si', '9');
INSERT INTO respuesta_pregunta_usuario VALUES (5637, 'Optimizar la visibilidad en línea de un sitio web o página web en los resultados impagos de  un motor de búsqueda.', 1, 'Correcto', 34, '70184250', 37, 'Si', '39');
INSERT INTO respuesta_pregunta_usuario VALUES (5599, '1 y 3.', 1, 'Correcto', 11, '70184250', 37, 'Si', '1');
INSERT INTO respuesta_pregunta_usuario VALUES (5638, 'Sponsorship.', 1, 'Correcto', 46, '70184250', 37, 'Si', '40');
INSERT INTO respuesta_pregunta_usuario VALUES (5619, 'Drip marketing.', 1, 'Correcto', 44, '70184250', 37, 'Si', '21');
INSERT INTO respuesta_pregunta_usuario VALUES (5636, '1, 2 y 3.', 0, 'Incorrecto', 62, '70184250', 37, 'Si', '38');
INSERT INTO respuesta_pregunta_usuario VALUES (5601, 'Un proceso para mejorar la visibilidad de su sitio web en los motores de búsqueda.', 1, 'Correcto', 63, '70184250', 37, 'Si', '3');
INSERT INTO respuesta_pregunta_usuario VALUES (5399, 'Affiliate marketing.', 1, 'Correcto', 39, '76407327', 36, 'Si', '4');
INSERT INTO respuesta_pregunta_usuario VALUES (5615, 'Verdadero.', 1, 'Correcto', 78, '70184250', 37, 'Si', '17');
INSERT INTO respuesta_pregunta_usuario VALUES (5401, 'Implementación de correo electrónico.', 0, 'Incorrecto', 42, '76407327', 36, 'Si', '6');
INSERT INTO respuesta_pregunta_usuario VALUES (5603, 'Hace que los usuarios visiten su sitio web.', 1, 'Correcto', 70, '70184250', 37, 'Si', '5');
INSERT INTO respuesta_pregunta_usuario VALUES (5402, 'Convertir.', 0, 'Incorrecto', 54, '76407327', 36, 'Si', '7');
INSERT INTO respuesta_pregunta_usuario VALUES (5559, 'Hace clic a un anuncio.', 1, 'Correcto', 36, '78998521', 34, 'Si', '1');
INSERT INTO respuesta_pregunta_usuario VALUES (5560, 'Depende de lo que Haya acordado con el blogger.', 0, 'Incorrecto', 64, '78998521', 34, 'Si', '2');
INSERT INTO respuesta_pregunta_usuario VALUES (5438, 'Marketing digital.', 0, 'Incorrecto', 69, '44643430', 33, 'Si', '1');
INSERT INTO respuesta_pregunta_usuario VALUES (5564, 'Modelo de negocios canvas.', 0, 'Incorrecto', 16, '78998521', 34, 'Si', '6');
INSERT INTO respuesta_pregunta_usuario VALUES (5565, 'Hace que los usuarios visiten su sitio web.', 1, 'Correcto', 70, '78998521', 34, 'Si', '7');
INSERT INTO respuesta_pregunta_usuario VALUES (5570, '1 y 3.', 0, 'Incorrecto', 21, '78998521', 34, 'Si', '12');
INSERT INTO respuesta_pregunta_usuario VALUES (5575, 'Falso.', 0, 'Incorrecto', 61, '78998521', 34, 'Si', '17');
INSERT INTO respuesta_pregunta_usuario VALUES (5581, 'Attract, convert, close y nurture.', 0, 'Incorrecto', 24, '78998521', 34, 'Si', '23');
INSERT INTO respuesta_pregunta_usuario VALUES (5583, 'Marketing impulsado por los datos.', 0, 'Incorrecto', 10, '78998521', 34, 'Si', '25');
INSERT INTO respuesta_pregunta_usuario VALUES (5584, 'Modelo de negocio canvas.', 1, 'Correcto', 68, '78998521', 34, 'Si', '26');
INSERT INTO respuesta_pregunta_usuario VALUES (5586, '1 y 3.', 1, 'Correcto', 62, '78998521', 34, 'Si', '28');
INSERT INTO respuesta_pregunta_usuario VALUES (5407, 'Attract, convert, close y delight.', 0, 'Incorrecto', 24, '76407327', 36, 'Si', '12');
INSERT INTO respuesta_pregunta_usuario VALUES (5408, 'Embudo de ingresos.', 1, 'Correcto', 30, '76407327', 36, 'Si', '13');
INSERT INTO respuesta_pregunta_usuario VALUES (5520, 'Cualquier cantidad de condiciones.', 1, 'Correcto', 41, '71407684', 35, 'Si', '3');
INSERT INTO respuesta_pregunta_usuario VALUES (5538, 'Optimizar la visibilidad en línea de un sitio web o página web en los resultados pagos de un  motor de búsqueda.', 0, 'Incorrecto', 34, '71407684', 35, 'Si', '21');
INSERT INTO respuesta_pregunta_usuario VALUES (5417, 'Mantener el sitio web actualizado.', 1, 'Correcto', 35, '76407327', 36, 'Si', '22');
INSERT INTO respuesta_pregunta_usuario VALUES (5530, 'falta', 0, 'Incorrecto', 64, '71407684', 35, 'Si', '13');
INSERT INTO respuesta_pregunta_usuario VALUES (5525, 'falta', 0, 'Incorrecto', 18, '71407684', 35, 'Si', '8');
INSERT INTO respuesta_pregunta_usuario VALUES (5526, 'falta', 0, 'Incorrecto', 37, '71407684', 35, 'Si', '9');
INSERT INTO respuesta_pregunta_usuario VALUES (5529, '2 y 3.', 1, 'Correcto', 21, '71407684', 35, 'Si', '12');
INSERT INTO respuesta_pregunta_usuario VALUES (5533, 'POS, brochures, exhibitions.', 0, 'Incorrecto', 28, '71407684', 35, 'Si', '16');
INSERT INTO respuesta_pregunta_usuario VALUES (5536, 'Un proceso para mejorar la visibilidad de su sitio web en los motores de búsqueda.', 1, 'Correcto', 63, '71407684', 35, 'Si', '19');
INSERT INTO respuesta_pregunta_usuario VALUES (5409, 'Nuevo contenido creado por una empresa.', 1, 'Correcto', 25, '76407327', 36, 'Si', '14');
INSERT INTO respuesta_pregunta_usuario VALUES (5410, 'Sales metrics. ', 0, 'Incorrecto', 51, '76407327', 36, 'Si', '15');
INSERT INTO respuesta_pregunta_usuario VALUES (5412, 'Navegador.', 1, 'Correcto', 60, '76407327', 36, 'Si', '17');
INSERT INTO respuesta_pregunta_usuario VALUES (5413, '1, 2 y 3.', 1, 'Correcto', 76, '76407327', 36, 'Si', '18');
INSERT INTO respuesta_pregunta_usuario VALUES (5414, 'Modelo de negocio canvas.', 1, 'Correcto', 68, '76407327', 36, 'Si', '19');
INSERT INTO respuesta_pregunta_usuario VALUES (5420, '1 y 2.', 1, 'Correcto', 74, '76407327', 36, 'Si', '25');
INSERT INTO respuesta_pregunta_usuario VALUES (5405, 'Drip marketing.', 1, 'Correcto', 44, '76407327', 36, 'Si', '10');
INSERT INTO respuesta_pregunta_usuario VALUES (5605, 'Inbound marketing.', 1, 'Correcto', 22, '70184250', 37, 'Si', '7');
INSERT INTO respuesta_pregunta_usuario VALUES (5609, 'Nuevo contenido creado por una empresa.', 1, 'Correcto', 25, '70184250', 37, 'Si', '11');
INSERT INTO respuesta_pregunta_usuario VALUES (5610, 'Metrics KPIs. ', 1, 'Correcto', 51, '70184250', 37, 'Si', '12');
INSERT INTO respuesta_pregunta_usuario VALUES (5616, 'Descubrir el mejor contenido, organizarlo, contextualizarlo y promocionarlo.', 0, 'Incorrecto', 27, '70184250', 37, 'Si', '18');
INSERT INTO respuesta_pregunta_usuario VALUES (5422, 'Content marketing.', 1, 'Correcto', 65, '76407327', 36, 'Si', '27');
INSERT INTO respuesta_pregunta_usuario VALUES (5425, 'Consideration.', 1, 'Correcto', 72, '76407327', 36, 'Si', '30');
INSERT INTO respuesta_pregunta_usuario VALUES (5614, 'Imágenes, texto, flash, video y audio.', 1, 'Correcto', 37, '70184250', 37, 'Si', '16');
INSERT INTO respuesta_pregunta_usuario VALUES (5620, 'Falso.', 0, 'Incorrecto', 61, '70184250', 37, 'Si', '22');
INSERT INTO respuesta_pregunta_usuario VALUES (5621, 'Convertir.', 0, 'Incorrecto', 54, '70184250', 37, 'Si', '23');
INSERT INTO respuesta_pregunta_usuario VALUES (5622, 'Search engine marketing.', 1, 'Correcto', 33, '70184250', 37, 'Si', '24');
INSERT INTO respuesta_pregunta_usuario VALUES (5623, 'Website retargeting.', 0, 'Incorrecto', 50, '70184250', 37, 'Si', '25');
INSERT INTO respuesta_pregunta_usuario VALUES (5625, 'Generar o aumentar las ventas en línea.', 0, 'Incorrecto', 19, '70184250', 37, 'Si', '27');
INSERT INTO respuesta_pregunta_usuario VALUES (5624, 'Todas las anteriores.', 1, 'Correcto', 40, '70184250', 37, 'Si', '26');
INSERT INTO respuesta_pregunta_usuario VALUES (5627, 'Estrategia de medios digitales.', 0, 'Incorrecto', 16, '70184250', 37, 'Si', '29');
INSERT INTO respuesta_pregunta_usuario VALUES (5629, 'Redes sociales.', 1, 'Correcto', 45, '70184250', 37, 'Si', '31');
INSERT INTO respuesta_pregunta_usuario VALUES (5631, 'Consideration.', 1, 'Correcto', 72, '70184250', 37, 'Si', '33');
INSERT INTO respuesta_pregunta_usuario VALUES (5632, 'Por cada registro que recibes de su blog.', 0, 'Incorrecto', 64, '70184250', 37, 'Si', '34');
INSERT INTO respuesta_pregunta_usuario VALUES (5633, 'Interested prospects, warm leads, hot leads.', 1, 'Correcto', 32, '70184250', 37, 'Si', '35');
INSERT INTO respuesta_pregunta_usuario VALUES (5634, 'falta', 0, 'Incorrecto', 57, '70184250', 37, 'Si', '36');
INSERT INTO respuesta_pregunta_usuario VALUES (5635, 'Blogs.', 1, 'Correcto', 75, '70184250', 37, 'Si', '37');
INSERT INTO respuesta_pregunta_usuario VALUES (5630, 'Modelo en línea canvas.', 0, 'Incorrecto', 68, '70184250', 37, 'Si', '32');
INSERT INTO respuesta_pregunta_usuario VALUES (5426, 'Marketing digital.', 0, 'Incorrecto', 69, '76407327', 36, 'Si', '31');
INSERT INTO respuesta_pregunta_usuario VALUES (5439, 'Verdadero.', 1, 'Correcto', 78, '44643430', 33, 'Si', '2');
INSERT INTO respuesta_pregunta_usuario VALUES (5442, 'Falso.', 0, 'Incorrecto', 66, '44643430', 33, 'Si', '5');
INSERT INTO respuesta_pregunta_usuario VALUES (5444, 'Capacidad de entrega.', 1, 'Correcto', 42, '44643430', 33, 'Si', '7');
INSERT INTO respuesta_pregunta_usuario VALUES (5446, 'Site retargeting.', 1, 'Correcto', 50, '44643430', 33, 'Si', '9');
INSERT INTO respuesta_pregunta_usuario VALUES (5447, '1 y 3.', 1, 'Correcto', 47, '44643430', 33, 'Si', '10');
INSERT INTO respuesta_pregunta_usuario VALUES (5448, 'Embudo de ingresos.', 1, 'Correcto', 30, '44643430', 33, 'Si', '11');
INSERT INTO respuesta_pregunta_usuario VALUES (5450, 'Facebook, linkedin.', 1, 'Correcto', 73, '44643430', 33, 'Si', '13');
INSERT INTO respuesta_pregunta_usuario VALUES (5453, 'Sponsorship.', 1, 'Correcto', 46, '44643430', 33, 'Si', '16');
INSERT INTO respuesta_pregunta_usuario VALUES (5452, 'Automatización de marketing.', 0, 'Incorrecto', 58, '44643430', 33, 'Si', '15');
INSERT INTO respuesta_pregunta_usuario VALUES (5454, 'Acciones en línea.', 0, 'Incorrecto', 48, '44643430', 33, 'Si', '17');
INSERT INTO respuesta_pregunta_usuario VALUES (5456, 'Inbound marketing.', 1, 'Correcto', 22, '44643430', 33, 'Si', '19');
INSERT INTO respuesta_pregunta_usuario VALUES (5458, '1, 2 y 3.', 0, 'Incorrecto', 62, '44643430', 33, 'Si', '21');
INSERT INTO respuesta_pregunta_usuario VALUES (5460, 'Por cada compra que se hace a través de su blog.', 1, 'Correcto', 64, '44643430', 33, 'Si', '23');
INSERT INTO respuesta_pregunta_usuario VALUES (5463, 'Pay funnel.', 1, 'Correcto', 67, '44643430', 33, 'Si', '26');
INSERT INTO respuesta_pregunta_usuario VALUES (5465, 'Redes sociales.', 1, 'Correcto', 45, '44643430', 33, 'Si', '28');
INSERT INTO respuesta_pregunta_usuario VALUES (5466, '1 y 2.', 1, 'Correcto', 74, '44643430', 33, 'Si', '29');
INSERT INTO respuesta_pregunta_usuario VALUES (5467, 'Modelo de negocios canvas.', 0, 'Incorrecto', 16, '44643430', 33, 'Si', '30');
INSERT INTO respuesta_pregunta_usuario VALUES (5440, 'Search engine marketing.', 1, 'Correcto', 33, '44643430', 33, 'Si', '3');
INSERT INTO respuesta_pregunta_usuario VALUES (5455, 'Navegador.', 1, 'Correcto', 60, '44643430', 33, 'Si', '18');
INSERT INTO respuesta_pregunta_usuario VALUES (5441, '«De» y «para», dirección postal válida y opción de exclusión.', 0, 'Incorrecto', 43, '44643430', 33, 'Si', '4');
INSERT INTO respuesta_pregunta_usuario VALUES (5443, 'Web y log.', 1, 'Correcto', 20, '44643430', 33, 'Si', '6');
INSERT INTO respuesta_pregunta_usuario VALUES (5445, 'Optimizar la visibilidad en línea de un sitio web o página web en los resultados impagos de  un motor de búsqueda.', 1, 'Correcto', 34, '44643430', 33, 'Si', '8');
INSERT INTO respuesta_pregunta_usuario VALUES (5457, 'Consideration.', 1, 'Correcto', 72, '44643430', 33, 'Si', '20');
INSERT INTO respuesta_pregunta_usuario VALUES (5597, 'Awareness, interest, consideration, consumption, advocacy.', 1, 'Correcto', 15, '78998521', 34, 'Si', '39');
INSERT INTO respuesta_pregunta_usuario VALUES (5595, '404', 0, 'Incorrecto', 38, '78998521', 34, 'Si', '37');
INSERT INTO respuesta_pregunta_usuario VALUES (5594, 'Adaptación.', 0, 'Incorrecto', 54, '78998521', 34, 'Si', '36');
INSERT INTO respuesta_pregunta_usuario VALUES (5592, 'Optimizar la visibilidad en línea de un sitio web o página web en los resultados pagos de un  motor de búsqueda.', 0, 'Incorrecto', 34, '78998521', 34, 'Si', '34');
INSERT INTO respuesta_pregunta_usuario VALUES (5551, 'Hace que los usuarios visiten su sitio web.', 1, 'Correcto', 70, '71407684', 35, 'Si', '34');
INSERT INTO respuesta_pregunta_usuario VALUES (5449, 'Awareness, interest, consideration, purchase, retention, advocacy.', 0, 'Incorrecto', 15, '44643430', 33, 'Si', '12');
INSERT INTO respuesta_pregunta_usuario VALUES (5451, 'Productos comprados.', 0, 'Incorrecto', 41, '44643430', 33, 'Si', '14');
INSERT INTO respuesta_pregunta_usuario VALUES (5459, 'Magazines, video, POS.', 0, 'Incorrecto', 28, '44643430', 33, 'Si', '22');
INSERT INTO respuesta_pregunta_usuario VALUES (5461, 'Falso.', 1, 'Correcto', 59, '44643430', 33, 'Si', '24');
INSERT INTO respuesta_pregunta_usuario VALUES (5462, 'Affiliate marketing.', 1, 'Correcto', 39, '44643430', 33, 'Si', '25');
INSERT INTO respuesta_pregunta_usuario VALUES (5464, 'Etapa Consideration.', 0, 'Incorrecto', 18, '44643430', 33, 'Si', '27');
INSERT INTO respuesta_pregunta_usuario VALUES (5468, 'falta', 0, 'Incorrecto', 38, '44643430', 33, 'Si', '31');
INSERT INTO respuesta_pregunta_usuario VALUES (5477, 'Convertir.', 0, 'Incorrecto', 54, '44643430', 33, 'Si', '40');
INSERT INTO respuesta_pregunta_usuario VALUES (5469, 'Todas las anteriores.', 1, 'Correcto', 31, '44643430', 33, 'Si', '32');
INSERT INTO respuesta_pregunta_usuario VALUES (5470, 'Imágenes, texto, flash, video y audio.', 1, 'Correcto', 37, '44643430', 33, 'Si', '33');
INSERT INTO respuesta_pregunta_usuario VALUES (5471, 'PPC.', 1, 'Correcto', 77, '44643430', 33, 'Si', '34');
INSERT INTO respuesta_pregunta_usuario VALUES (5472, 'Interested prospects, warm leads, hot leads.', 1, 'Correcto', 32, '44643430', 33, 'Si', '35');
INSERT INTO respuesta_pregunta_usuario VALUES (5474, 'Todas las anteriores.', 1, 'Correcto', 13, '44643430', 33, 'Si', '37');
INSERT INTO respuesta_pregunta_usuario VALUES (5475, 'Un proceso para mejorar la visibilidad de su sitio web en los motores de búsqueda.', 1, 'Correcto', 63, '44643430', 33, 'Si', '38');
INSERT INTO respuesta_pregunta_usuario VALUES (5590, 'Digital marketing.', 0, 'Incorrecto', 22, '78998521', 34, 'Si', '32');
INSERT INTO respuesta_pregunta_usuario VALUES (5561, 'Facebook, linkedin.', 1, 'Correcto', 73, '78998521', 34, 'Si', '3');
INSERT INTO respuesta_pregunta_usuario VALUES (5562, 'Todas las anteriores.', 1, 'Correcto', 17, '78998521', 34, 'Si', '4');
INSERT INTO respuesta_pregunta_usuario VALUES (5563, 'Innovating.', 0, 'Incorrecto', 46, '78998521', 34, 'Si', '5');
INSERT INTO respuesta_pregunta_usuario VALUES (5566, 'Un blog.', 1, 'Correcto', 79, '78998521', 34, 'Si', '8');
INSERT INTO respuesta_pregunta_usuario VALUES (5567, 'Búsqueda orgánica.', 0, 'Incorrecto', 31, '78998521', 34, 'Si', '9');
INSERT INTO respuesta_pregunta_usuario VALUES (5568, '4 y 1.', 0, 'Incorrecto', 57, '78998521', 34, 'Si', '10');
INSERT INTO respuesta_pregunta_usuario VALUES (5569, '1 y 3.', 0, 'Incorrecto', 14, '78998521', 34, 'Si', '11');
INSERT INTO respuesta_pregunta_usuario VALUES (5571, 'Estudios de mercado.', 1, 'Correcto', 19, '78998521', 34, 'Si', '13');
INSERT INTO respuesta_pregunta_usuario VALUES (5572, 'Content marketing.', 1, 'Correcto', 65, '78998521', 34, 'Si', '14');
INSERT INTO respuesta_pregunta_usuario VALUES (5573, '1, 2 y 3.', 1, 'Correcto', 76, '78998521', 34, 'Si', '15');
INSERT INTO respuesta_pregunta_usuario VALUES (5574, 'Ninguna de las anteriores.', 1, 'Correcto', 27, '78998521', 34, 'Si', '16');
INSERT INTO respuesta_pregunta_usuario VALUES (5576, 'Purchase history', 0, 'Incorrecto', 52, '78998521', 34, 'Si', '18');
INSERT INTO respuesta_pregunta_usuario VALUES (5577, 'Ninguno de los anteriores.', 0, 'Incorrecto', 32, '78998521', 34, 'Si', '19');
INSERT INTO respuesta_pregunta_usuario VALUES (5578, 'Imágenes y video.', 0, 'Incorrecto', 37, '78998521', 34, 'Si', '20');
INSERT INTO respuesta_pregunta_usuario VALUES (5579, 'Etapa Purchase.', 0, 'Incorrecto', 18, '78998521', 34, 'Si', '21');
INSERT INTO respuesta_pregunta_usuario VALUES (5580, 'Campañas preestablecidas.', 0, 'Incorrecto', 58, '78998521', 34, 'Si', '22');
INSERT INTO respuesta_pregunta_usuario VALUES (5582, 'Consideration.', 1, 'Correcto', 72, '78998521', 34, 'Si', '24');
INSERT INTO respuesta_pregunta_usuario VALUES (5585, 'Associate marketing.', 0, 'Incorrecto', 39, '78998521', 34, 'Si', '27');
INSERT INTO respuesta_pregunta_usuario VALUES (5587, 'Brand y log.', 0, 'Incorrecto', 20, '78998521', 34, 'Si', '29');
INSERT INTO respuesta_pregunta_usuario VALUES (5588, 'Blog.', 0, 'Incorrecto', 45, '78998521', 34, 'Si', '30');
INSERT INTO respuesta_pregunta_usuario VALUES (5598, 'Verdadero.', 1, 'Correcto', 66, '78998521', 34, 'Si', '40');
INSERT INTO respuesta_pregunta_usuario VALUES (5596, 'KPIs revenue. ', 0, 'Incorrecto', 51, '78998521', 34, 'Si', '38');
INSERT INTO respuesta_pregunta_usuario VALUES (5589, 'Nuevo contenido creado por una empresa.', 1, 'Correcto', 25, '78998521', 34, 'Si', '31');
INSERT INTO respuesta_pregunta_usuario VALUES (5523, 'Modelo de negocio canvas.', 1, 'Correcto', 68, '71407684', 35, 'Si', '6');
INSERT INTO respuesta_pregunta_usuario VALUES (5524, 'Una compilación de los mejores blogs.', 0, 'Incorrecto', 25, '71407684', 35, 'Si', '7');
INSERT INTO respuesta_pregunta_usuario VALUES (5527, 'Affiliate marketing.', 1, 'Correcto', 39, '71407684', 35, 'Si', '10');
INSERT INTO respuesta_pregunta_usuario VALUES (5531, 'Drip marketing.', 1, 'Correcto', 58, '71407684', 35, 'Si', '14');
INSERT INTO respuesta_pregunta_usuario VALUES (5532, 'PPC.', 1, 'Correcto', 77, '71407684', 35, 'Si', '15');
INSERT INTO respuesta_pregunta_usuario VALUES (5534, 'Sponsorship.', 1, 'Correcto', 46, '71407684', 35, 'Si', '17');
INSERT INTO respuesta_pregunta_usuario VALUES (5535, 'Marketing digital.', 0, 'Incorrecto', 69, '71407684', 35, 'Si', '18');
INSERT INTO respuesta_pregunta_usuario VALUES (5537, 'Todas las anteriores.', 1, 'Correcto', 40, '71407684', 35, 'Si', '20');
INSERT INTO respuesta_pregunta_usuario VALUES (5539, 'Mantener el sitio web actualizado.', 1, 'Correcto', 35, '71407684', 35, 'Si', '22');
INSERT INTO respuesta_pregunta_usuario VALUES (5540, 'Inbound marketing.', 1, 'Correcto', 22, '71407684', 35, 'Si', '23');
INSERT INTO respuesta_pregunta_usuario VALUES (5541, 'Todas las anteriores.', 1, 'Correcto', 13, '71407684', 35, 'Si', '24');
INSERT INTO respuesta_pregunta_usuario VALUES (5545, 'PPC.', 0, 'Incorrecto', 79, '71407684', 35, 'Si', '28');
INSERT INTO respuesta_pregunta_usuario VALUES (5546, 'Descubrir el mejor contenido, organizarlo, contextualizarlo y promocionarlo.', 0, 'Incorrecto', 27, '71407684', 35, 'Si', '29');
INSERT INTO respuesta_pregunta_usuario VALUES (5547, 'Marketing basado en análisis de datos.', 0, 'Incorrecto', 10, '71407684', 35, 'Si', '30');
INSERT INTO respuesta_pregunta_usuario VALUES (5548, 'Website retargeting.', 0, 'Incorrecto', 50, '71407684', 35, 'Si', '31');
INSERT INTO respuesta_pregunta_usuario VALUES (5542, 'Embudo de ingresos.', 1, 'Correcto', 30, '71407684', 35, 'Si', '25');
INSERT INTO respuesta_pregunta_usuario VALUES (5543, 'Facebook, linkedin.', 1, 'Correcto', 73, '71407684', 35, 'Si', '26');
INSERT INTO respuesta_pregunta_usuario VALUES (5518, 'falta', 0, 'Incorrecto', 71, '71407684', 35, 'Si', '1');
INSERT INTO respuesta_pregunta_usuario VALUES (5544, 'Dirección postal válida, borre «de» y «a», revele claramente que su mensaje es publicitario, tenga la opción y haga que sea fácil optar por no participar, respete las exclusiones en 10 días, no use lenguaje engañoso, asegúrese de que todas las firmas estén en conformidad.', 1, 'Correcto', 43, '71407684', 35, 'Si', '27');
INSERT INTO respuesta_pregunta_usuario VALUES (5403, 'Modelo de negocios canvas.', 0, 'Incorrecto', 16, '76407327', 36, 'Si', '8');
INSERT INTO respuesta_pregunta_usuario VALUES (5406, '302', 1, 'Correcto', 38, '76407327', 36, 'Si', '11');
INSERT INTO respuesta_pregunta_usuario VALUES (5411, 'POS, brochures, exhibitions.', 0, 'Incorrecto', 28, '76407327', 36, 'Si', '16');
INSERT INTO respuesta_pregunta_usuario VALUES (5415, 'Falso.', 1, 'Correcto', 59, '76407327', 36, 'Si', '20');
INSERT INTO respuesta_pregunta_usuario VALUES (5416, 'Falso.', 0, 'Incorrecto', 78, '76407327', 36, 'Si', '21');
INSERT INTO respuesta_pregunta_usuario VALUES (5418, '1 y 3.', 1, 'Correcto', 62, '76407327', 36, 'Si', '23');
INSERT INTO respuesta_pregunta_usuario VALUES (5419, 'Generar o aumentar las ventas en línea.', 0, 'Incorrecto', 19, '76407327', 36, 'Si', '24');
INSERT INTO respuesta_pregunta_usuario VALUES (5421, 'CTR. ', 1, 'Correcto', 52, '76407327', 36, 'Si', '26');
INSERT INTO respuesta_pregunta_usuario VALUES (5423, '4 y 1.', 0, 'Incorrecto', 57, '76407327', 36, 'Si', '28');
INSERT INTO respuesta_pregunta_usuario VALUES (5428, 'Todas las anteriores.', 1, 'Correcto', 40, '76407327', 36, 'Si', '33');


--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: ipvedupe
--

INSERT INTO usuario VALUES ('47412369', 'Carolina', 'Sol Guerrero', 'Av. Guardia Civil, urb. Proceres #4455. Surco', '963365412', 'CarolinaSolGuerrero@hotmail.com', 2);
INSERT INTO usuario VALUES ('4561233', 'Marco', 'Pérez Hurtado', '---------------------------', '963223698', 'marcoPeresHurtado@hotmail.com', 6);
INSERT INTO usuario VALUES ('70184250', 'Alvaro', 'Mendoza ', 'Lima ', '987654321', 'alvaro.mendoza@alfirk.org.pe', 6);
INSERT INTO usuario VALUES ('44643430', 'Jean', 'Baldoceda Chávez ', 'Lima', '12345y7io', 'jean.baldoceda@ipv.edu.pe', 5);
INSERT INTO usuario VALUES ('45977448', 'Renzo', 'Ruiz Pastor', 'Av. Guardia Civil #953, urb. La campiña. Distrito de Chorrillos', '996031277', 'marco.ruiz@alfirk.org.pe', 4);
INSERT INTO usuario VALUES ('07853952', 'Nora', 'Basterrechea Blest', 'Lima ', '123456789', 'nora.basterrechea@alfirk.org.pe', 6);
INSERT INTO usuario VALUES ('70464700', 'Paola', 'Ladera Sánchez ', 'Lima', '984797960', 'paola.ladera@ipv.edu.pe', 3);
INSERT INTO usuario VALUES ('78998521', 'Cesar', 'Valqui Barraza', 'Av. Guardia Civil, urb. Proceres #4456. Surco', '999026167', 'cesar.valqui@alfirk.org.pe', 1);
INSERT INTO usuario VALUES ('71407684', 'Gabriela ', 'Anaya Oliva', 'Lima ', '1234567i0', 'gabriela.anaya@alfirk.org.pe', 6);
INSERT INTO usuario VALUES ('76407327', 'Andrea', 'Moreno Castañeda', 'Lima', '123456789', 'andrea.moreno@alfirk.org.pe', 6);
INSERT INTO usuario VALUES ('88888888', 'usuario profesor', 'demo', '--------------------------------', '989898989', 'demoprofesor@hotmail.com', 5);


--
-- Name: menu_pkey; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY menu
    ADD CONSTRAINT menu_pkey PRIMARY KEY (codigo_menu);


--
-- Name: pk_anuncio_anuncio_id; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY anuncio
    ADD CONSTRAINT pk_anuncio_anuncio_id PRIMARY KEY (anuncio_id);


--
-- Name: pk_cargo; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY cargo
    ADD CONSTRAINT pk_cargo PRIMARY KEY (cargo_id);


--
-- Name: pk_codigo_usuario; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY credenciales_acceso
    ADD CONSTRAINT pk_codigo_usuario PRIMARY KEY (codigo_usuario);


--
-- Name: pk_correlativo; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY correlativo
    ADD CONSTRAINT pk_correlativo PRIMARY KEY (tabla);


--
-- Name: pk_curso_curso_id; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY curso
    ADD CONSTRAINT pk_curso_curso_id PRIMARY KEY (curso_id);


--
-- Name: pk_detalle_usuario_curso_evento_detalle_usuario_curso_evento_id; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY detalle_usuario_curso_evento
    ADD CONSTRAINT pk_detalle_usuario_curso_evento_detalle_usuario_curso_evento_id PRIMARY KEY (detalle_usuario_curso_evento_id);


--
-- Name: pk_menu_item; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY menu_item
    ADD CONSTRAINT pk_menu_item PRIMARY KEY (codigo_menu, codigo_menu_item);


--
-- Name: pk_menu_item_accesos; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY menu_item_accesos
    ADD CONSTRAINT pk_menu_item_accesos PRIMARY KEY (codigo_menu, codigo_menu_item, cargo_id);


--
-- Name: pk_pregunta_pregunta_id; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY pregunta
    ADD CONSTRAINT pk_pregunta_pregunta_id PRIMARY KEY (pregunta_id);


--
-- Name: pk_promedio_promedio_id; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY promedio
    ADD CONSTRAINT pk_promedio_promedio_id PRIMARY KEY (promedio_id);


--
-- Name: pk_prueba_prueba_id; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY prueba
    ADD CONSTRAINT pk_prueba_prueba_id PRIMARY KEY (prueba_id);


--
-- Name: pk_respuesta_pregunta_usuario_id; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY respuesta_pregunta_usuario
    ADD CONSTRAINT pk_respuesta_pregunta_usuario_id PRIMARY KEY (respuesta_pregunta_usuario_id);


--
-- Name: pk_usuario_doc_id; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT pk_usuario_doc_id PRIMARY KEY (doc_id);


--
-- Name: uni_email; Type: CONSTRAINT; Schema: public; Owner: ipvedupe; Tablespace: 
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT uni_email UNIQUE (email);


--
-- Name: fk_detalle_usuario_curso_evento_anuncio_id; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY detalle_usuario_curso_evento
    ADD CONSTRAINT fk_detalle_usuario_curso_evento_anuncio_id FOREIGN KEY (anuncio_id) REFERENCES anuncio(anuncio_id);


--
-- Name: fk_detalle_usuario_curso_evento_curso_id; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY detalle_usuario_curso_evento
    ADD CONSTRAINT fk_detalle_usuario_curso_evento_curso_id FOREIGN KEY (curso_id) REFERENCES curso(curso_id);


--
-- Name: fk_detalle_usuario_curso_evento_doc_id; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY detalle_usuario_curso_evento
    ADD CONSTRAINT fk_detalle_usuario_curso_evento_doc_id FOREIGN KEY (doc_id) REFERENCES usuario(doc_id);


--
-- Name: fk_doc_id; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY respuesta_pregunta_usuario
    ADD CONSTRAINT fk_doc_id FOREIGN KEY (doc_id) REFERENCES usuario(doc_id);


--
-- Name: fk_menu_item_accesos_cargo_id; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY menu_item_accesos
    ADD CONSTRAINT fk_menu_item_accesos_cargo_id FOREIGN KEY (cargo_id) REFERENCES cargo(cargo_id);


--
-- Name: fk_menu_item_accesos_menu_item; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY menu_item_accesos
    ADD CONSTRAINT fk_menu_item_accesos_menu_item FOREIGN KEY (codigo_menu, codigo_menu_item) REFERENCES menu_item(codigo_menu, codigo_menu_item);


--
-- Name: fk_menu_item_menu; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY menu_item
    ADD CONSTRAINT fk_menu_item_menu FOREIGN KEY (codigo_menu) REFERENCES menu(codigo_menu);


--
-- Name: fk_pregunta_id; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY respuesta_pregunta_usuario
    ADD CONSTRAINT fk_pregunta_id FOREIGN KEY (pregunta_id) REFERENCES pregunta(pregunta_id);


--
-- Name: fk_pregunta_prueba_id; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY pregunta
    ADD CONSTRAINT fk_pregunta_prueba_id FOREIGN KEY (prueba_id) REFERENCES prueba(prueba_id);


--
-- Name: fk_promedio_promedio_id; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY respuesta_pregunta_usuario
    ADD CONSTRAINT fk_promedio_promedio_id FOREIGN KEY (promedio_id) REFERENCES promedio(promedio_id);


--
-- Name: fk_prueba_curso_id; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY prueba
    ADD CONSTRAINT fk_prueba_curso_id FOREIGN KEY (curso_id) REFERENCES curso(curso_id);


--
-- Name: fk_usuario_cargo_id; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT fk_usuario_cargo_id FOREIGN KEY (cargo_id) REFERENCES cargo(cargo_id);


--
-- Name: fk_usuario_doc_id; Type: FK CONSTRAINT; Schema: public; Owner: ipvedupe
--

ALTER TABLE ONLY credenciales_acceso
    ADD CONSTRAINT fk_usuario_doc_id FOREIGN KEY (doc_id) REFERENCES usuario(doc_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: f_generar_correlativo(character varying); Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON FUNCTION f_generar_correlativo(p_tabla character varying) FROM PUBLIC;
REVOKE ALL ON FUNCTION f_generar_correlativo(p_tabla character varying) FROM ipvedupe;
GRANT ALL ON FUNCTION f_generar_correlativo(p_tabla character varying) TO ipvedupe;
GRANT ALL ON FUNCTION f_generar_correlativo(p_tabla character varying) TO PUBLIC;
GRANT ALL ON FUNCTION f_generar_correlativo(p_tabla character varying) TO ipvedupe_admin;


--
-- Name: fn_calificarexamen(character varying, integer); Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON FUNCTION fn_calificarexamen(p_doc_id character varying, p_prueba_id integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION fn_calificarexamen(p_doc_id character varying, p_prueba_id integer) FROM ipvedupe;
GRANT ALL ON FUNCTION fn_calificarexamen(p_doc_id character varying, p_prueba_id integer) TO ipvedupe;
GRANT ALL ON FUNCTION fn_calificarexamen(p_doc_id character varying, p_prueba_id integer) TO PUBLIC;
GRANT ALL ON FUNCTION fn_calificarexamen(p_doc_id character varying, p_prueba_id integer) TO ipvedupe_admin;


--
-- Name: fn_calificarexamennull(character varying, integer); Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON FUNCTION fn_calificarexamennull(p_doc_id character varying, p_prueba_id integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION fn_calificarexamennull(p_doc_id character varying, p_prueba_id integer) FROM ipvedupe;
GRANT ALL ON FUNCTION fn_calificarexamennull(p_doc_id character varying, p_prueba_id integer) TO ipvedupe;
GRANT ALL ON FUNCTION fn_calificarexamennull(p_doc_id character varying, p_prueba_id integer) TO PUBLIC;
GRANT ALL ON FUNCTION fn_calificarexamennull(p_doc_id character varying, p_prueba_id integer) TO ipvedupe_admin;


--
-- Name: fn_editarusuario(integer, character varying, character varying, character varying, character varying, character varying, character, character, character varying, integer, character, character, character); Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON FUNCTION fn_editarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) FROM PUBLIC;
REVOKE ALL ON FUNCTION fn_editarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) FROM ipvedupe;
GRANT ALL ON FUNCTION fn_editarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) TO ipvedupe;
GRANT ALL ON FUNCTION fn_editarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) TO PUBLIC;
GRANT ALL ON FUNCTION fn_editarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) TO ipvedupe_admin;


--
-- Name: fn_eliminarcursopruebapregunta(integer); Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON FUNCTION fn_eliminarcursopruebapregunta(p_curso_id integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION fn_eliminarcursopruebapregunta(p_curso_id integer) FROM ipvedupe;
GRANT ALL ON FUNCTION fn_eliminarcursopruebapregunta(p_curso_id integer) TO ipvedupe;
GRANT ALL ON FUNCTION fn_eliminarcursopruebapregunta(p_curso_id integer) TO PUBLIC;
GRANT ALL ON FUNCTION fn_eliminarcursopruebapregunta(p_curso_id integer) TO ipvedupe_admin;


--
-- Name: fn_eliminarrespuestapromedio(character varying, integer); Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON FUNCTION fn_eliminarrespuestapromedio(p_doc_id character varying, p_prueba_id integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION fn_eliminarrespuestapromedio(p_doc_id character varying, p_prueba_id integer) FROM ipvedupe;
GRANT ALL ON FUNCTION fn_eliminarrespuestapromedio(p_doc_id character varying, p_prueba_id integer) TO ipvedupe;
GRANT ALL ON FUNCTION fn_eliminarrespuestapromedio(p_doc_id character varying, p_prueba_id integer) TO PUBLIC;
GRANT ALL ON FUNCTION fn_eliminarrespuestapromedio(p_doc_id character varying, p_prueba_id integer) TO ipvedupe_admin;


--
-- Name: fn_eliminarusuario(character varying); Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON FUNCTION fn_eliminarusuario(p_doc_id character varying) FROM PUBLIC;
REVOKE ALL ON FUNCTION fn_eliminarusuario(p_doc_id character varying) FROM ipvedupe;
GRANT ALL ON FUNCTION fn_eliminarusuario(p_doc_id character varying) TO ipvedupe;
GRANT ALL ON FUNCTION fn_eliminarusuario(p_doc_id character varying) TO PUBLIC;
GRANT ALL ON FUNCTION fn_eliminarusuario(p_doc_id character varying) TO ipvedupe_admin;


--
-- Name: fn_registrareditarprueba(integer, character varying, character varying, integer, integer); Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON FUNCTION fn_registrareditarprueba(p_prueba_id integer, p_cant_preguntas character varying, p_tiempo_prueba character varying, p_puntaje_aprobacion integer, p_curso_id integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION fn_registrareditarprueba(p_prueba_id integer, p_cant_preguntas character varying, p_tiempo_prueba character varying, p_puntaje_aprobacion integer, p_curso_id integer) FROM ipvedupe;
GRANT ALL ON FUNCTION fn_registrareditarprueba(p_prueba_id integer, p_cant_preguntas character varying, p_tiempo_prueba character varying, p_puntaje_aprobacion integer, p_curso_id integer) TO ipvedupe;
GRANT ALL ON FUNCTION fn_registrareditarprueba(p_prueba_id integer, p_cant_preguntas character varying, p_tiempo_prueba character varying, p_puntaje_aprobacion integer, p_curso_id integer) TO PUBLIC;
GRANT ALL ON FUNCTION fn_registrareditarprueba(p_prueba_id integer, p_cant_preguntas character varying, p_tiempo_prueba character varying, p_puntaje_aprobacion integer, p_curso_id integer) TO ipvedupe_admin;


--
-- Name: fn_registrarrespuestausuario(character, integer, character varying); Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON FUNCTION fn_registrarrespuestausuario(p_respuesta_usuario character, p_pregunta_id integer, p_doc_id character varying) FROM PUBLIC;
REVOKE ALL ON FUNCTION fn_registrarrespuestausuario(p_respuesta_usuario character, p_pregunta_id integer, p_doc_id character varying) FROM ipvedupe;
GRANT ALL ON FUNCTION fn_registrarrespuestausuario(p_respuesta_usuario character, p_pregunta_id integer, p_doc_id character varying) TO ipvedupe;
GRANT ALL ON FUNCTION fn_registrarrespuestausuario(p_respuesta_usuario character, p_pregunta_id integer, p_doc_id character varying) TO PUBLIC;
GRANT ALL ON FUNCTION fn_registrarrespuestausuario(p_respuesta_usuario character, p_pregunta_id integer, p_doc_id character varying) TO ipvedupe_admin;


--
-- Name: fn_registrarusuario(integer, character varying, character varying, character varying, character varying, character varying, character, character, character varying, integer, character, character, character); Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON FUNCTION fn_registrarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) FROM PUBLIC;
REVOKE ALL ON FUNCTION fn_registrarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) FROM ipvedupe;
GRANT ALL ON FUNCTION fn_registrarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) TO ipvedupe;
GRANT ALL ON FUNCTION fn_registrarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) TO PUBLIC;
GRANT ALL ON FUNCTION fn_registrarusuario(p_codigo_usuario integer, p_doc_id character varying, p_nombres character varying, p_apellidos character varying, p_direccion character varying, p_telefono character varying, p_sexo character, p_edad character, p_email character varying, p_cargo_id integer, p_clave character, p_tipo character, p_estado character) TO ipvedupe_admin;


--
-- Name: anuncio; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE anuncio FROM PUBLIC;
REVOKE ALL ON TABLE anuncio FROM ipvedupe;
GRANT ALL ON TABLE anuncio TO ipvedupe;
GRANT ALL ON TABLE anuncio TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE anuncio TO ipvedupe_admin;


--
-- Name: cargo; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE cargo FROM PUBLIC;
REVOKE ALL ON TABLE cargo FROM ipvedupe;
GRANT ALL ON TABLE cargo TO ipvedupe;
GRANT ALL ON TABLE cargo TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE cargo TO ipvedupe_admin;


--
-- Name: cargo_cargo_id_seq; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON SEQUENCE cargo_cargo_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE cargo_cargo_id_seq FROM ipvedupe;
GRANT ALL ON SEQUENCE cargo_cargo_id_seq TO ipvedupe;
GRANT ALL ON SEQUENCE cargo_cargo_id_seq TO ipvedupe_admin;


--
-- Name: correlativo; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE correlativo FROM PUBLIC;
REVOKE ALL ON TABLE correlativo FROM ipvedupe;
GRANT ALL ON TABLE correlativo TO ipvedupe;
GRANT ALL ON TABLE correlativo TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE correlativo TO ipvedupe_admin;


--
-- Name: credenciales_acceso; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE credenciales_acceso FROM PUBLIC;
REVOKE ALL ON TABLE credenciales_acceso FROM ipvedupe;
GRANT ALL ON TABLE credenciales_acceso TO ipvedupe;
GRANT ALL ON TABLE credenciales_acceso TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE credenciales_acceso TO ipvedupe_admin;


--
-- Name: curso; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE curso FROM PUBLIC;
REVOKE ALL ON TABLE curso FROM ipvedupe;
GRANT ALL ON TABLE curso TO ipvedupe;
GRANT ALL ON TABLE curso TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE curso TO ipvedupe_admin;


--
-- Name: detalle_usuario_curso_evento; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE detalle_usuario_curso_evento FROM PUBLIC;
REVOKE ALL ON TABLE detalle_usuario_curso_evento FROM ipvedupe;
GRANT ALL ON TABLE detalle_usuario_curso_evento TO ipvedupe;
GRANT ALL ON TABLE detalle_usuario_curso_evento TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE detalle_usuario_curso_evento TO ipvedupe_admin;


--
-- Name: menu; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE menu FROM PUBLIC;
REVOKE ALL ON TABLE menu FROM ipvedupe;
GRANT ALL ON TABLE menu TO ipvedupe;
GRANT ALL ON TABLE menu TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE menu TO ipvedupe_admin;


--
-- Name: menu_item; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE menu_item FROM PUBLIC;
REVOKE ALL ON TABLE menu_item FROM ipvedupe;
GRANT ALL ON TABLE menu_item TO ipvedupe;
GRANT ALL ON TABLE menu_item TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE menu_item TO ipvedupe_admin;


--
-- Name: menu_item_accesos; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE menu_item_accesos FROM PUBLIC;
REVOKE ALL ON TABLE menu_item_accesos FROM ipvedupe;
GRANT ALL ON TABLE menu_item_accesos TO ipvedupe;
GRANT ALL ON TABLE menu_item_accesos TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE menu_item_accesos TO ipvedupe_admin;


--
-- Name: pregunta; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE pregunta FROM PUBLIC;
REVOKE ALL ON TABLE pregunta FROM ipvedupe;
GRANT ALL ON TABLE pregunta TO ipvedupe;
GRANT ALL ON TABLE pregunta TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE pregunta TO ipvedupe_admin;


--
-- Name: promedio; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE promedio FROM PUBLIC;
REVOKE ALL ON TABLE promedio FROM ipvedupe;
GRANT ALL ON TABLE promedio TO ipvedupe;
GRANT ALL ON TABLE promedio TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE promedio TO ipvedupe_admin;


--
-- Name: prueba; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE prueba FROM PUBLIC;
REVOKE ALL ON TABLE prueba FROM ipvedupe;
GRANT ALL ON TABLE prueba TO ipvedupe;
GRANT ALL ON TABLE prueba TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE prueba TO ipvedupe_admin;


--
-- Name: respuesta_pregunta_usuario; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE respuesta_pregunta_usuario FROM PUBLIC;
REVOKE ALL ON TABLE respuesta_pregunta_usuario FROM ipvedupe;
GRANT ALL ON TABLE respuesta_pregunta_usuario TO ipvedupe;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE respuesta_pregunta_usuario TO ipvedupe_admin;
GRANT ALL ON TABLE respuesta_pregunta_usuario TO "ipvedupe_campusVirtual_bd";


--
-- Name: usuario; Type: ACL; Schema: public; Owner: ipvedupe
--

REVOKE ALL ON TABLE usuario FROM PUBLIC;
REVOKE ALL ON TABLE usuario FROM ipvedupe;
GRANT ALL ON TABLE usuario TO ipvedupe;
GRANT ALL ON TABLE usuario TO "ipvedupe_campusVirtual_bd";
GRANT ALL ON TABLE usuario TO ipvedupe_admin;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: ipvedupe
--

ALTER DEFAULT PRIVILEGES FOR ROLE ipvedupe IN SCHEMA public REVOKE ALL ON TABLES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE ipvedupe IN SCHEMA public REVOKE ALL ON TABLES  FROM ipvedupe;
ALTER DEFAULT PRIVILEGES FOR ROLE ipvedupe IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO ipvedupe_admin;


--
-- PostgreSQL database dump complete
--

